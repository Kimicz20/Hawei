#include "ga.h"
#include <algorithm>
/**
 * @brief GA::GA 构造
 * @param _bord
 */
GA::GA(Graph &_graph)
{
    graph = _graph;
    srand( (unsigned)time(NULL) );//初始化时间种子
}


/**
 * @brief GA::init 初始化n个可行的解
 * @param n
 */
void GA::init(int n)
{
    int iter =0;
    std::set<int> serverList;
    
     int stardFlow = 0.1 * graph.consumeMaxFlow;

     while(iter++ < n ){
	     int nowCap = stardFlow + iter;
		 int cntBig = 0;

		 //将于消费节点直连且能提供费用的节点 基因序号置为1
		 for (int i = 0; i<graph.consumeNodesNum; i++){

		 	Graph::Arc *e = graph.conAndnetArcs[i];
		 	if (e->cap >= nowCap)
		 	{
		 		serverList.insert(e->to);
		 		cntBig++;
		 	}
		 }
		

		 int ranCount = rand() % (graph.consumeNodesNum - cntBig);
		 for (int i = 0; i<ranCount; i++){
		 	int index = rand() % graph.allNetNodes.size();
		 	serverList.insert(graph.allNetNodes[index]->nodeID);
		 }

		 cout<<"大于 "<<nowCap<<" 的容量有 "<<cntBig<<" 个,补全个数:"<<ranCount<<" 服务器补全后有: "<<serverList.size()<<" 个。"<<endl;
//		随机档次
         std::vector<int> ranDC;
         for (int i=0;i<graph.netNodesNum;i++)
         {
             int r = rand() % graph.serverDC.size();
             ranDC.push_back(graph.serverDC[r]);
         }

         graph.setServerMaxOutPutLimit(ranDC);
         GT gene(serverList,graph);
	 	// cout<<"是否可行："<<gene.cost<<endl;
	 	if(gene.cost >0){
	 		gts.push(gene);
	 	}
	 	serverList.clear();
	 }

	 cout<<"size :"<<gts.size()<<endl;
	 //种群个数太少，变异其中某几个
	 if(gts.size() == 0){
	    for (int i=0;i<graph.conAndnetArcs.size();i++)
	    {
	        serverList.insert(graph.conAndnetArcs[i]->to);
	    }
	    GT gene(serverList,graph);
        if(gene.cost >0){
            gts.push(gene);
        }
	 }
	cout<<"populaction init ok"<<endl;
}

/**
 * @brief GA::change 变异
 * @param g 个体
 * @param graph 图
 */
 int type1=0,type2=0,type3=0,type4=0;
void GA::change(GT &g,Graph &graph)
{
    double ran = (double)(rand() % 100) / 100;
    GT tmp = g;
    // 删:加:移 = 1:1:1
    if(ran < 0.66) {
        int deletedId = ranDelete(tmp);
        tmp.updateCost(graph);
        if(g.cost>tmp.cost){
            type1++;
//            g = tmp;
        }
    }  
    else if(ran < 1){
        //如果是移动
        ranMove(tmp,graph);
        tmp.updateCost(graph);
        if(g.cost>tmp.cost){
            type2++;
//            g = tmp;
        }
    }
    g = tmp;
}

void GA::change2(GT &g,Graph &graph)
{
    double ran = (double)(rand() % 100) / 100;
    GT tmp = g;
    if(ran < 0.1) {
       int deletedId = ranDelete(tmp);
        tmp.updateCost(graph);
       if(g.cost>tmp.cost){
           type1++;
           g = tmp;
       }
    }
    else if(ran < 0.6){
        //如果是移动
        ranMove(tmp,graph);
        tmp.updateCost(graph);
        if(g.cost>tmp.cost){
            type2++;
//            g = tmp;
        }
    }
    else if(ran < 1){
        // 如果是添加
        int addedId = ranAdd(tmp,graph);
        tmp.updateCost(graph);
        if(g.cost>tmp.cost){
            type3++;
//            g = tmp;
        }
    }
    else if(ran < 0.8){
        upDC(g,graph);
    }
    g = tmp;
}


void GA::upDC(GT &gt,Graph &graph){
    GT tmp = gt;
    sort(tmp.gene.begin(),tmp.gene.end());
    int index,total=0;
    for (int i = 0; i < tmp.gene.size(); ++i) {
        if(tmp.gene[i] >0){
            total+=tmp.gene[i];
            index++;
        }
    }

    for (int j = 0; j < tmp.gene.size(); ++j) {
        if(tmp.gene[j] >0 && tmp.gene[j] < (total / index)){
            tmp.gene[j] = total / index ;
        }
    }

    tmp.updateCost(graph);
    if(gt.cost>tmp.cost){
        type4++;
        gt = tmp;
    }
}


/**
 * @brief GA::cross 交叉
 * @param g1 个体1
 * @param g2 个体2
 * @return 原来的两个个体+新的两个个体
 */
std::set<GT> GA::cross(GT &g1, GT &g2,Graph &graph)
{
    vector<int> gene1 = g1.gene;
    vector<int> gene2 = g2.gene;
    set<int> serverIds1 = g1.serverIds;
    set<int> serverIds2 = g2.serverIds;

    int size = gene1.size() <= gene2.size() ? gene1.size():gene1.size();

    int indexLow = rand() % size;
    int indexHigh = rand() % size;

    if(indexLow > indexHigh) {
        indexLow^=indexHigh; indexHigh^=indexLow; indexLow^=indexHigh;
    }

    // 交换从indexLow 到 indexHigh的基因序列
    for(int i = indexLow; i <= indexHigh; i++) {
        if(gene1[i] == gene2[i]) continue;
        if(gene1[i] >0 && gene2[i] == 0) {
            serverIds1.erase(i); 
            serverIds2.insert(i);
        }
        if(gene1[i] == 0 && gene2[i] > 0) {
            serverIds2.erase(i); 
            serverIds1.insert(i);
        }

        gene1[i] ^= gene2[i];gene2[i] ^= gene1[i]; gene1[i] ^= gene2[i];

    }

    GT child1(serverIds1, gene1,graph);
    GT child2(serverIds2, gene2,graph);

    set<GT> res;
    if(g1.cost >0)
        res.insert(g1);
    if(g2.cost >0)
        res.insert(g2);
    if(child1.cost >0)
    	res.insert(child1);
    if(child2.cost >0)
    	res.insert(child2);

    return res;
}


/**
 * @brief GA::ranDelete 随机删除一个id
 * @param ids
 * @return 删除的那个id
 */
int GA::ranDelete(GT &gt)
{
    int deleteIndex = rand() % gt.serverIds.size();
    int index = 0,deletedId;
    for(std::set<int>::iterator it = gt.serverIds.begin();it != gt.serverIds.end(); it++) {
        if(index++ == deleteIndex) {
            deletedId = *it;
            gt.serverIds.erase(*it);
            break;
        }
    }
    gt.gene[deletedId] = 0;
    return deletedId;
}
/**
 * @brief GA::ranAdd 随机加一个没有的id
 * @param ids
 * @param sizeOfNode 所有的可选节点id 0-sizeOfNode
 * @return 加的id
 */
int GA::ranAdd(GT &gt, Graph &graph)
{
    int sizeOfNode = graph.allNetNodes.size();
    int osize = gt.serverIds.size();
    int addId = 0;
    // do {
        //随机加一个没有的id
        do{
            addId = rand() % sizeOfNode;
        }while(gt.serverIds.find(addId) != gt.serverIds.end());
        gt.serverIds.insert(addId);
        //随机档次
        int r = rand() % graph.serverDC.size();
        int r1 = (rand() % 100) *1.0 / 100;
        // if(r1<0.5){
            gt.gene[addId] = graph.serverDC[r] < 100 ? graph.serverDC[r]+100:graph.serverDC[r];
        // }else{
        //     gt.gene[addId] = graph.serverDC[r];
        // }
    // }while(gt.serverIds.size() == osize);
    return addId;
}
/**
 * @brief GA::ranMove 随机选择一个移动一格
 * @param ids
 * @param graph 图
 * @return pait(删除的id，移动到那个点的id)
 */
std::pair<int,int> GA::ranMove(GT &gt,Graph &graph)
{
    int deleteIndex = rand() % gt.serverIds.size();
    int index = 0;
    int deletedId = 0;
    for(std::set<int>::iterator it = gt.serverIds.begin(); it != gt.serverIds.end(); it++) {
        if(index++ == deleteIndex) {
            deletedId = *it;
        }
    }
    // 先删除
    gt.serverIds.erase(deletedId);


    // 添加
    Graph::Node *selectedNode = graph.allNetNodes[deletedId];
    std::vector<Graph::Node *> linkedNodes = selectedNode->linkNodes;

    int moveToId = 0;
    int moveToIndex = rand() % linkedNodes.size();
    moveToId = linkedNodes[moveToIndex]->nodeID;
    // 再加上
    gt.serverIds.insert(moveToId);

    std::vector<int> gene = gt.gene;
    gene[deletedId] ^= gene[moveToId];
    gene[moveToId] ^= gene[deletedId];
    gene[deletedId] ^= gene[moveToId];
    gt.gene = gene;
    // deletedId -> moveToId
    return make_pair(deletedId,moveToId);
}


bool Comp(const GT &a,const GT &b)
{
    return a.cost < b.cost;
}

/**
 * @brief GA::getGeneByIds 根据id构造基因序列
 * @param ids
 * @return 一个基因序列
 */
std::vector<int> GA::getGeneByIds(std::set<int> &ids,Graph &graph)
{
    int size = GENE_LENGTH;
    vector<int> res(size);

    for(set<int>::iterator it = ids.begin();it != ids.end(); it++) {
        int r = rand() % graph.serverDC.size();
        //随机档次
        int r1 = (rand() % 100) *1.0 / 100;
        if(r1<0.5){
            res[*it] = graph.serverDC[r] < 100 ? graph.serverDC[r]+100:graph.serverDC[r];
        }else{
            res[*it] = graph.serverDC[r];
        }
    }

    return res;
}

string GA::xjbs(){
    clock_t start_time = clock();
    int size = gts.size(),gener=0;
    std::set<GT> gt_v;
    while((clock()-start_time)/CLOCKS_PER_SEC<88){
    	gt_v.clear();
    	while(!gts.empty()){
    		GT g0 = gts.top();
    		gt_v.insert(g0);
    		gts.pop();
    	}
        int curTotalCost=0;
	//cout<<"第"<<++gener<<"代 ++++";
//        sort(gt_v.begin(),gt_v.end());
        for(set<GT>::iterator iter=gt_v.begin();iter !=gt_v.end();++iter){
            cout <<(*iter).cost << " ";
            curTotalCost+=(*iter).cost;
        }
	cout << endl; 
    	//cout<<"第几代:"<<++gener<< "fuwuqigeshu:"<<gt_v[gt_v.size()-1].serverIds.size()<<"+++++++"<<gt_v[gt_v.size()-1].cost<<endl;
        for(set<GT>::iterator iter=gt_v.begin();iter !=gt_v.end();++iter)
    	{
		    GT gti =  *iter;
    		double r = (double) (rand() % 100) /100;
    		GT gt303 = gti;
    		gts.push(gt303);
		
    		//变异
    		if(r<1.0 / (gt_v.size() - size +2)){
                if((clock()-start_time)/CLOCKS_PER_SEC < 30)
                    change(gti,graph);
                else {
                    change2(gti,graph);
                }
                //选择加入
                // if(gti.cost > 0 && gti.cost < (curTotalCost / gt_v.size())){
                if(gti.cost > 0  ) {
                    gts.push(gti);
                }
    		} 

    		double r2 = (double) (rand() % 100) /100;
    		//交叉

            set<GT> gtCross;
    		// if(r2<  (clock()-start_time)*1.0/CLOCKS_PER_SEC / 660 && (clock()-start_time)/CLOCKS_PER_SEC >80){
    		if((clock()-start_time)/CLOCKS_PER_SEC > 30 && (clock()-start_time)/CLOCKS_PER_SEC %6 ==0){
            	double r4 =(double) (rand() % 100)*1.0 /100;
    			int r3 ;
                gtCross.clear();
    			// if(r4 < (clock()-start_time)*1.0 /CLOCKS_PER_SEC / 160){
                if(r4 < 0.5){
                    set<GT>::iterator k;
    				do{
                        k=gt_v.begin();
    	    			r3= rand() % gt_v.size();
                        while(r3--){
                            k++;
                        }
    				}while(k != iter);
                    GT otherG =  *k;
                    gtCross = cross(gti,otherG,graph);
    			}
                 else{
                    set<GT>::iterator k=badGts.begin();
                    r3= rand() % badGts.size();
                    while(r3--){
                        k++;
                    }
                    GT otherG =  *k;
                    gtCross = cross(gti,otherG,graph);
    			 }
                for(set<GT>::iterator it=gtCross.begin();it !=gtCross.end();++it)
    			{
                    cout << "jiaocha  ::"<<(*it).cost<< endl;
    				gts.push((*it));
    			}

    		}
    	}
		while(gts.size() > size + (clock()-start_time)/CLOCKS_PER_SEC/ 5){
            badGts.insert(gts.top());
    		gts.pop();
		}
		//cout<<"badGts Size:"<<badGts.size()<<endl;
    }
    GT finallG = *(gt_v.begin());
    cout<<"min Cost"<<finallG.cost<<endl;
    cout<<"删除:"<<type1<<endl;
    cout<<"移动:"<<type2<<endl;
    cout<<"添加:"<<type3<<endl;
    cout<<"upDc:"<<type4<<endl;
    MCMF_YCW mcmf(graph,finallG.serverIds,finallG.gene);

    mcmf.isOutputResult = true;
    cout << mcmf.greenTea()<<endl;

    string result("");
    mcmf.print_solution(result);
    return result;
}
