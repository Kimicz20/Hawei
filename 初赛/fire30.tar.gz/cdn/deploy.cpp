#include "deploy.h"
#include "maxFlow.hpp"
#include <queue>
#include <cstdio>
#include <iostream>
#include <cassert>
#include <string.h>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <sys/types.h>
#include <set>
#include <ctime>
#include <math.h>
#include <random>

using namespace std;
#define N 2000
// #define INF 100000000
int TIME_OUT = 88;//设置超时时间
double acceptValue = 1000;

vector<int> serverIndex;
int serverPrice; //服务器成本
int superSource,superSink;
int totalFlow=0;//总流量
int netStates,netRoutes,consumeStates;
int minCost ;

vector<string> lastPaths;//最终最短路径集合
set<int> lastServerIndex;//最终服务器节点
vector<set<int>> population;//可行服务器位置种群
vector<string> shortPaths;//最短路径集合

vector<vector<int>> linkNodes;//备份每个节点的灵域节点

struct MCMF_ZKW mcmf_zkw_bak;//费用流备份部分图


char * outputFile;//输出文件位置
set<int> borderNetStates;//与消费节点相邻的网络节点id
set<int> itServers;//每次迭代求解的服务器位置
set<int> notUsedServers;//未放置服务器的网络节点集合
set<int> tempServers;
set<int> hashCodes;//存放所有历史服务器位置集合的hashcode

int netLinkInfo[6000][4];//网络链路备份信息
int consumeInfo[1000][3];//消费节点备份信息

clock_t start_time;//程序开始时间
bool timeout = false;//是否超时

int countx = 0;// 随机种子

int a[] = {0,0,0,0,0,0,0,0};
vector<int> deleteTime;
vector<int> addTime;
vector<int> moveTime;
int type = 0;
int reCount = 0;

struct Edge {
    int from,to,cap,flow,cost;
    Edge(int u,int v,int ca,int f,int co):from(u),to(v),cap(ca),flow(f),cost(co) {};
};

struct MCMF {
    int n,m,s,t;
    vector<Edge> edges;
    vector<int> G[N];
    int inq[N];//是否在队列中
    int d[N];//距离
    int p[N];//上一条弧
    int a[N];//可改进量
    
    void init(int n) { //初始化
        this->n=n;
        for(int i=0; i<n; i++)
            G[i].clear();
        edges.clear();
    }
    
    void addedge(int from,int to,int cap,int cost) { //加边
        edges.push_back(Edge(from,to,cap,0,cost));
        edges.push_back(Edge(to,from,0,0,-cost));
        int m=edges.size();
        G[from].push_back(m-2);
        G[to].push_back(m-1);
    }
    
    bool SPFA(int s,int t,int &flow,int &cost) { //寻找最小费用的增广路，使用引用同时修改原flow,cost
        for(int i=0; i<n; i++)
            d[i]=INF;
        memset(inq,0,sizeof(inq));
        d[s]=0;
        inq[s]=1;
        p[s]=0;
        a[s]=INF;
        queue<int> Q;
        Q.push(s);
        while(!Q.empty()) {
            int u=Q.front();
            Q.pop();
            inq[u]--;
            for(int i=0; i<G[u].size(); i++) {
                Edge& e=edges[G[u][i]];
                if(e.cap>e.flow && d[e.to]>d[u]+e.cost) { //满足可增广且可变短
                    d[e.to]=d[u]+e.cost;
                    p[e.to]=G[u][i];
                    a[e.to]=min(a[u],e.cap-e.flow);
                    if(!inq[e.to]) {
                        inq[e.to]++;
                        Q.push(e.to);
                    }
                }
            }
        }
        if(d[t]==INF) return false;//汇点不可达则退出
        flow+=a[t];
        cost+=d[t]*a[t];
        int u=t;
        while(u!=s) { //更新正向边和反向边
            edges[p[u]].flow+=a[t];
            edges[p[u]^1].flow-=a[t];
            u=edges[p[u]].from;
        }
        return true;
    }
    
    int MincotMaxflow(int s,int t) {
        int flow=0,cost=0;
        while(SPFA(s,t,flow,cost));
        // cout<<"flow ："<<flow<<"   totalFlow :"<<totalFlow<<endl;
        // cout<<"尚未满足的流量需求："<<flow-totalFlow<<endl;
        if(flow<totalFlow) {
            return -1;
        }
        return cost;
    }
} mcmf_bak;




void printInfo(){
    cout<<"总需求："<<totalFlow<<endl<<"服务器个数:"<<lastServerIndex.size()<<endl<<"服务器位置：";
    
    /*for(set<int>::iterator it=lastServerIndex.begin();it!=lastServerIndex.end();++it){
     // cout<<*it<<"  ";
     cout<<*it<<",";
     }*/
    cout<<endl;
    
    printf("最小费用：%d\n",minCost);
    
}

int totalComputeCount =0;
void buildGraphAndSearch(){
    
    struct MCMF mcmf = mcmf_bak;
    
    //添加超源到服务器的边
    for(set<int>::iterator it=itServers.begin();it!=itServers.end();++it){
        mcmf.addedge(superSource, *it, INF, 0);
        mcmf.addedge(*it, superSource, INF, 0);
    }
    clock_t begin = clock();
    
    int currCost = mcmf.MincotMaxflow(superSource,superSink);
    // cout<<"计算费用流时间："<<(clock()-begin)*1000.0/CLOCKS_PER_SEC<<endl;
    
    
    if(currCost>0&&currCost+serverPrice*itServers.size()<minCost
       && (type != 1 || (minCost - currCost - serverPrice*itServers.size()) > acceptValue/2) ) {
        // type != 1 不是删除服务器 则不判断接受值 、、、如果是删除 需要判断接受值
        a[type] ++;// 相应类型的次数加1
        if (type == 1) {
            deleteTime.push_back((clock()-start_time)/CLOCKS_PER_SEC);
        } else if(type == 2) {
            addTime.push_back((clock()-start_time)/CLOCKS_PER_SEC);
        } else {
            moveTime.push_back((clock()-start_time)/CLOCKS_PER_SEC);
        }
        //		cout <<(minCost - currCost - serverPrice*itServers.size()) * 1.0  << "   " << ran << endl;
        minCost = currCost+serverPrice*itServers.size();
        // lastPaths = shortPaths;
        lastServerIndex = itServers;
        set<int> goodServers(itServers);
        population.push_back(goodServers);
        if(population.size()>1){
            population.erase(population.begin());
        }
        
        printInfo();
        
    }else{
        itServers = tempServers;
    }
}
int counta = 0;
void buildGraphAndFilter(){
    
    struct MCMF_ZKW mcmf_zkw = mcmf_zkw_bak;
    mcmf_zkw.numOfserver = (int)itServers.size();
    
    //添加超源到服务器的边
    for(set<int>::iterator it=itServers.begin();it!=itServers.end();++it){
        mcmf_zkw.AddEdge(superSource, *it, INF, 0);
        // mcmf_zkw.AddEdge(*it, superSource, INF, 0);
    }
    
    clock_t begin = clock();
    //cout<<"计算费用里之前"<<endl;
    int currCost = mcmf_zkw.zkw(superSource,superSink,totalFlow);
    //cout<< "次数"<<counta++<< endl;
    //	cout<<currCost<<"+++"<<minCost<<endl;
    // cout<<"计算zkw费用流时间："<<(clock()-begin)*1000.0/CLOCKS_PER_SEC<<endl;
    //cout<<"计算费用里之hou"<<endl;
    
    if(currCost>0&&currCost<minCost
       && (type != 1 || (minCost - currCost) > acceptValue/2)) {
        // type != 1 不是删除服务器 则不判断接受值 、、、如果是删除 需要判断接受值
        a[type] ++;// 相应类型的次数加1
        if (type == 1) {
            deleteTime.push_back((clock()-start_time)/CLOCKS_PER_SEC);
        } else if(type == 2) {
            addTime.push_back((clock()-start_time)/CLOCKS_PER_SEC);
        } else {
            moveTime.push_back((clock()-start_time)/CLOCKS_PER_SEC);
        }
        //		cout <<(minCost - currCost - serverPrice*itServers.size()) * 1.0  << "   " << ran << endl;
        minCost = currCost;
        // lastPaths = shortPaths;
        lastServerIndex = itServers;
        set<int> goodServers(itServers);
        population.push_back(goodServers);
        if(population.size()>1){
            population.erase(population.begin());
        }
        
        // printInfo();
        
    }else{
        
        itServers = tempServers;
    }
}

//计算单次最小费用流
int onceMcmf(){
    
    struct MCMF mcmf = mcmf_bak;
    
    //添加超源到服务器的边
    for(set<int>::iterator it=itServers.begin();it!=itServers.end();++it){
        mcmf.addedge(superSource, *it, INF, 0);
        mcmf.addedge(*it, superSource, INF, 0);
    }
    clock_t begin = clock();
    
    int currCost = mcmf.MincotMaxflow(superSource,superSink);
    return currCost;
}


//计算单次zkw最小费用流
int onceZKW(){
    
    struct MCMF_ZKW mcmf_zkw = mcmf_zkw_bak;
    mcmf_zkw.numOfserver = (int)itServers.size();
    
    //添加超源到服务器的边
    for(set<int>::iterator it=itServers.begin();it!=itServers.end();++it){
        mcmf_zkw.AddEdge(superSource, *it, INF, 0);
        // mcmf_zkw.AddEdge(*it, superSource, INF, 0);
    }
    
    // clock_t begin = clock();
    //cout<<"计算费用里之前"<<endl;
    int currCost = mcmf_zkw.zkw(superSource,superSink,totalFlow);
   
    // cout<<"计算zkw费用流时间："<<(clock()-begin)*1000.0/CLOCKS_PER_SEC<<endl;
    return currCost;
}


//判断当前的itservers是否历史计算过
bool isComputed(){
    //计算当前的itservers的hashcode
    int currHashCode=1;
    for(set<int>::iterator it=itServers.begin();it!=itServers.end();++it){
        currHashCode = currHashCode*31+(*it);
    }
    if(hashCodes.find(currHashCode)!=hashCodes.end()){
        return true;
    }else{
        hashCodes.insert(currHashCode);
        return false;
    }
}

//---------------变异---------------------------------------------------------------------------------------
// 随机删除一个
void randelete(){
    type = 1;
    srand((unsigned)time(NULL)+countx++);
    // cout<<"itservers.size:"<<itServers.size()<<endl;
    int r = rand()%(itServers.size());
    // cout<<"randeleter:"<<r<<endl;
    set<int>::iterator point= itServers.begin();
    while(r--){
        point++;
    }
    itServers.erase(point);
}
// 添加一个没有的
void addNotUsedServer(){
    type = 2;
    
    if (netStates < 999) {
        int size = itServers.size();
        do{
            
            srand((unsigned)time(NULL)+countx++);
            int r = rand()%(netStates);
            itServers.insert(r);
        }while(itServers.size()==size);

    } else {// 高级只加边界值
    
        int size = itServers.size();
        do{
            
            srand((unsigned)time(NULL)+countx++);
            int r = rand()%(borderNetStates.size());
            set<int>::iterator point= borderNetStates.begin();
            while(r--){
                point++;
            }
            itServers.insert(r + *point);
        }while(itServers.size()==size);
    
    }
    
    
    
    
    
}
// 移动一格
void moveOneServer() {
    type = 3;
    //addNotUsedServer();
    srand((unsigned)time(NULL)+countx++);
    int r = (int)rand()%(itServers.size());
    int value;
    for (int i = 0; i < 1; i++) {
        set<int>::iterator point= itServers.begin();
        while(r--){
            point++;
        }
        value = *point;
        itServers.erase(point);
        srand((unsigned)time(NULL)+countx++);
        int ran = (int)rand()%(linkNodes[value].size());
        itServers.insert(linkNodes[value][ran]);
    }
}
//---------------初级---------------------------------------------------------------------------------------
int tt = 0;
set<int> bestIds;
int bestCost = 100000;
void chooseServerSimple() {
   /* if ((clock()-start_time)/CLOCKS_PER_SEC / 8 != tt) {
        if (minCost < bestCost) {
            bestCost = minCost;
            minCost = 100000;
            bestIds = lastServerIndex;// 记录最小
        } else {
            minCost = 100000;
        }
        itServers = borderNetStates;
        tt++;
    }*/

    acceptValue = 1;
    int random2;
    tempServers = itServers;
    double ran = (double)(rand() % 100) / 100;
    
    // 删:加:移 = 4:1:1
    if(ran < 0.54) {
        randelete();
    } else if(ran < 0.64){
        addNotUsedServer();
    }else {
        moveOneServer();
    }
}

//my 初级
void myChooseServerSimple() {
    acceptValue = 1;
    int random2;
    tempServers = itServers;
    double ran = -(double)rand() / (RAND_MAX + 1);
    // 删:加:移 = 4:1:1
    if(ran < 0.43) {//0.43   //0.35
        randelete(); type = 1;

    } else if(ran < 0.57){//0.57   //0.5
        addNotUsedServer(); type = 2;
    }else if(ran < 0.72){//0.72   //0.75
    	randelete();
        addNotUsedServer(); type = 4;
    }else {
        type = 3;
        srand((unsigned)time(NULL)+countx++);
        random2 = (int)rand()%(itServers.size());
        tempServers = itServers;
        int value;
        for (int i = 0; i < 1; i++) {
            set<int>::iterator point= itServers.begin();
            while(random2--){
                point++;
            }
            value = *point;
            itServers.erase(point);
            srand((unsigned)time(NULL)+countx++);
            int ran = (int)rand()%(linkNodes[value].size());
            itServers.insert(linkNodes[value][ran]);
        }
        // moveOneServer();
    }
}

//中级
void chooseServerMedium() {
    acceptValue = 1;
    int random2;
    tempServers = itServers;
    double ran = (double)(rand() % 100) / 100;
    
    // 删:加:移 = 4:1:1
    if(ran < 0.5) {
        randelete();
    } else if(ran < 0.6){
        addNotUsedServer();
    }else {
        moveOneServer();
    }
}

// 高级变异
void specialChange() {
    double ran = (double)(rand() % 100) / 100;
    
    // 删:加:移 = 1:1:1
    if(ran < 0.5) {
        randelete();
    }  else if(ran < 0.8){
        moveOneServer();
    } else if(ran < 0.9){
        addNotUsedServer();
    }else{
        moveOneServer();
        addNotUsedServer();
        type = 4;
    }
    
}

void chooseServerAdvance() {
    if ((clock()-start_time)/CLOCKS_PER_SEC % 10 == 0) {
        cout << "+++++++++++++++++++++++++++++++++++++"<<(clock()-start_time)/CLOCKS_PER_SEC<< "++++++" << minCost << endl;
    }
    int r;
    int random2;
    int ran;
    tempServers = itServers;
    
    if ((clock()-start_time)/CLOCKS_PER_SEC < 2) { // P1
        randelete();
    } else if((clock()-start_time)/CLOCKS_PER_SEC < 5) {// P2
        acceptValue = 900;
        specialChange();
    } else if((clock()-start_time)/CLOCKS_PER_SEC < 7) {// P3
        acceptValue = 800;
        randelete();
    }else if((clock()-start_time)/CLOCKS_PER_SEC < 10) {// P6
        acceptValue = 700;
        specialChange();
    }else if((clock()-start_time)/CLOCKS_PER_SEC < 12) {// P7
        acceptValue = 600;
        randelete();
    }else if((clock()-start_time)/CLOCKS_PER_SEC < 15) {// P8
        acceptValue = 500;
        specialChange();
    }else if((clock()-start_time)/CLOCKS_PER_SEC < 17) {// P8
        acceptValue = 400;
        randelete();
    }else if((clock()-start_time)/CLOCKS_PER_SEC < 20) {// P8
        acceptValue = 1;
        specialChange();
    }else {// P5
        acceptValue = 1;
        
        specialChange();
    }
}



//筛选服务器点
void chooseServer(){
    
    if (netStates > 500) {
        chooseServerAdvance(); // 高级
    } else if(netStates > 200) {
        chooseServerMedium();// 中级
    } else { // 初级
        // chooseServerSimple();
        myChooseServerSimple();
        // cout<<"初级simple筛选"<<endl;
    }
}


////模拟退火算法
int annealTime = 0;
int preCost;
void anneal(){
	double temperature = 360;
	double coolingRate = 0.95;
	// cout<<"coolingRate"<<coolingRate<<endl;
	int deltaCost = 0;
	int absoluteTemperature = 0.6;
	int totalComp = 0;
	if(annealTime==0){
		preCost = minCost;

		itServers = borderNetStates;
	}

	while(temperature>absoluteTemperature && (clock()-start_time)/CLOCKS_PER_SEC<TIME_OUT){
		int count= 100;
		int unAcTimes = 0;
		while(count-- && unAcTimes<10){

			while(true){
				// cout<<"count:"<<count<<endl;
				chooseServer();
				int currCost = onceZKW();

				totalComp++;
				if(currCost<=0){
					// cout<<"无解出现"<<endl;
					itServers = tempServers;
					continue;
				}else{
					deltaCost = currCost-preCost;
					if(deltaCost<=0){
						preCost = currCost;
						cout<<"接受好的解："<<preCost<<endl;
						 a[type] ++;// 相应类型的次数加1
						 if (type == 1) {
				            deleteTime.push_back((clock()-start_time)/CLOCKS_PER_SEC);
				        } else if(type == 2) {
				            addTime.push_back((clock()-start_time)/CLOCKS_PER_SEC);
				        } else {
				            moveTime.push_back((clock()-start_time)/CLOCKS_PER_SEC);
				        }
						unAcTimes = 0;
						if(preCost<minCost){
							minCost = preCost;
							if(minCost==28371) return ;
							lastServerIndex = itServers;

						}
					}else{
						srand((unsigned)time(NULL)+countx++);
						double prob = -(double)rand()/(RAND_MAX+1);
						double p = exp(-deltaCost*1.0/temperature);
						// cout<<"prob:"<<prob<<endl<<"接受胡坏解概率p："<<p<<endl;
						if(prob<p){
							preCost = currCost;
							cout<<"一定概率接受坏的解："<<preCost<<endl;
							unAcTimes = 0;
						}else{
							unAcTimes++;
							itServers = tempServers;
						}
						// itServers = tempServers;
					}

					break;
				}
			}

		}
		temperature *= coolingRate;
		cout<<"temperature:"<<temperature<<endl;
	}
	cout<<"最小费用："<<minCost<<endl;
	cout<<"计算次数："<<totalComp<<endl;
}



void xjbs_sec(){
    
    
    
    itServers = borderNetStates;
    // clock_t end_time = clock();
    while(itServers.size()>consumeStates/4&&(clock()-start_time)/CLOCKS_PER_SEC<TIME_OUT){
        
        chooseServer();
        if(isComputed()){
            itServers = tempServers;
            continue;
        }
        buildGraphAndSearch();
        totalComputeCount++;
        
    }
    // anneal();
}

void xjbs_forth(){
    
    
    
    itServers = borderNetStates;
    // clock_t end_time = clock();
    while((clock()-start_time)/CLOCKS_PER_SEC<TIME_OUT){
        
        chooseServer();
        /*if(isComputed()){
         itServers = tempServers;
         continue;
         }*/
        //cout<<"新的费用流算法"<<endl;
        buildGraphAndFilter();
        totalComputeCount++;
        
    }
    // anneal();
}

/*void xjbs_sec(){
	
	// clock_t end_time = clock();
	while((clock()-start_time)/CLOCKS_PER_SEC<TIME_OUT){
 srand((unsigned)time(NULL));
 // cout<<"population.size:"<<population.size()<<endl;
 int r = rand()%(population.size());
 // cout<<"population:"<<r<<endl;
 itServers = population[r];
 
 // int count = netStates/3;
 int count = 66;
 while(count--){
 chooseServer();
 
 if(itServers.size()<consumeStates/4  || (clock()-start_time)/CLOCKS_PER_SEC>TIME_OUT){
 break;
 }
 
 buildGraphAndSearch();
 totalComputeCount++;
 }
	}
 }*/
vector<int> path;//存放一条路径上的点下标
vector<Edge*> edgePath;//存放一条路径上的边
//查找费用流路径
void searchPath() {
    
    //收集路径之前先计算最后一次最优服务器位置的费用流
    struct MCMF last_mcmf = mcmf_bak;
    //添加超源到服务器的边
    for(set<int>::iterator it=lastServerIndex.begin();it!=lastServerIndex.end();++it){
        last_mcmf.addedge(superSource, *it, INF, 0);
        last_mcmf.addedge(*it, superSource, INF, 0);
    }
    //计算最小费用流以得到残留图
    int lastMinCost = last_mcmf.MincotMaxflow(superSource,superSink);
    
    lastPaths.clear();
    bool flag = false;
    while(true) {
        int u = superSource;
        int minFlowOfPath = 10000;
        path.clear();
        edgePath.clear();
        while(u!=superSink) {
            path.push_back(u);
            for(int i=0; i<last_mcmf.G[u].size(); i++) {
                
                Edge& e=last_mcmf.edges[last_mcmf.G[u][i]];
                if(e.flow>0) { //flow大于0的边才需要搜索
                    
                    minFlowOfPath = min(minFlowOfPath,e.flow);
                    
                    edgePath.push_back(&e) ;
                    u = e.to;
                    break;
                }
            }
            if(u==superSource) {
                flag = true;
                break;
            }
        }
        if(flag) {
            break;
        }
        string onePath = "";
        for(int j=1; j<path.size(); j++) {
            char tm[6];
            if(j!=path.size()-1) {
                sprintf(tm,"%d",path[j]);
            } else {
                sprintf(tm,"%d",path[j]-netStates);
            }
            
            string t= tm;
            onePath += t+" ";
        }
        char tmp[600];
        sprintf(tmp,"%s%d",onePath.c_str(),minFlowOfPath);
        onePath =  tmp;
        lastPaths.push_back(onePath);
        
        //在路径上删除最小流量
        for(int k=0; k<edgePath.size(); k++) {
            edgePath[k]->flow -= minFlowOfPath;
        }
        
    }
    
    
    //输出最小费用路径
    /*cout<<"最小费用："<<lastMinCost+serverPrice*lastServerIndex.size()<<endl<<lastPaths.size()<<endl<<endl;
     for(int k=0;k<lastPaths.size();k++){
     cout<<lastPaths[k]<<endl;
     
     }*/
}

void outputTXT(){
    // string outstr = "";
    char outstr[26000];
    sprintf(outstr,"%d%s",lastPaths.size(),"\n\n");
    
    for(int k=0;k<lastPaths.size();k++){
        
        sprintf(outstr,"%s%s%s",outstr,lastPaths[k].c_str(),"\n");
    }
    
    //需要输出的内容
    char * topo_file = outstr;
    
    // 直接调用输出文件的方法输出到指定文件中(ps请注意格式的正确性，如果有解，第一行只有一个数据；第二行为空；第三行开始才是具体的数据，数据之间用一个空格分隔开)
    write_result(topo_file, outputFile);
}

//初始化 3.初始解 2.不变的部分图结构备份 1.各参数读取初始化
void init(char ** topo){
    //读取第一行
    
    char* firstLine = topo[0];
    char* tmp;
    char t[256];
    char* tmp2;
    char* tmp3;
    tmp = strtok(firstLine," ");
    netStates = atoi(tmp);
    tmp = strtok(NULL," ");
    netRoutes = atoi(tmp);
    tmp = strtok(NULL," ");
    consumeStates = atoi(tmp);
    int n = netStates+consumeStates+2;//总结点数
    //m = netRoutes+consumeStates+serversNum+consumeStates;//总边数
    mcmf_bak.init(n) ;
    
    //计算添加的超级源点和超级汇点的索引
    superSource = netStates+consumeStates;
    superSink = superSource+1;
    
    //读取第三行
    char* thirdLine = topo[2];
    serverPrice = atoi(thirdLine);
    
    mcmf_zkw_bak.init(n,netStates,consumeStates,serverPrice);
    // mcmf_zkw_bak.costNow = -1;
    //初始化linkNodes
    linkNodes.resize(netStates*2);
    for(int i =0;i<netStates;i++){
        linkNodes[i].resize(0);
    }
    
    //读取第五行
    for(int i=4;i<4+netRoutes;i++){
        char* netLine = topo[i];
        tmp = strtok(netLine," ");
        int netState1 = atoi(tmp);
        tmp = strtok(NULL," ");
        int netState2 = atoi(tmp);
        tmp = strtok(NULL," ");
        int cap = atoi(tmp);
        tmp = strtok(NULL," ");
        int cost = atoi(tmp);
        
        //备份网络链路信息
        netLinkInfo[i-4][0] = netState1;
        netLinkInfo[i-4][1] = netState2;
        netLinkInfo[i-4][2] = cap;
        netLinkInfo[i-4][3] = cost;
        
        linkNodes[netState1].push_back(netState2);
        linkNodes[netState2].push_back(netState1);
        
        //旧爱
        mcmf_bak.addedge(netState1,netState2,cap,cost);
        mcmf_bak.addedge(netState2,netState1,cap,cost);
        //新欢
        mcmf_zkw_bak.AddEdge(netState1,netState2,cap,cost);
        mcmf_zkw_bak.AddEdge(netState2,netState1,cap,cost);
        
    }
    //读取剩下的消费节点信息行
    for(int i=5+netRoutes;i<5+netRoutes+consumeStates;i++){
        
        char* consumeLine = topo[i];
        // char* tmp2,tmp3;
        tmp = strtok(consumeLine," ");
        int consumeID = atoi(tmp);
        tmp2 = strtok(NULL," ");
        int netStateID = atoi(tmp2);
        borderNetStates.insert(netStateID);
        tmp3 = strtok(NULL," ");
        tmp3 = strtok(tmp3,"\n");
        int need = atoi(tmp3);
        
        
        //备份消费节点信息
        consumeInfo[i-5-netRoutes][0] = consumeID;
        consumeInfo[i-5-netRoutes][1] = netStateID;
        consumeInfo[i-5-netRoutes][2] = need;
        
        totalFlow += need;
        
        sprintf(t,"%s %s %s",tmp2,tmp,tmp3);
        string oneRoute = t;
        lastPaths.push_back(oneRoute);//初始解路径
        //旧爱
        //消费节点编号接着网络节点后面
        mcmf_bak.addedge(consumeID+netStates,netStateID,need,0);
        mcmf_bak.addedge(netStateID,consumeID+netStates,need,0);
        //添加超汇到消费点的边
        mcmf_bak.addedge(superSink, consumeID+netStates, need, 0);
        mcmf_bak.addedge(consumeID+netStates, superSink, need, 0);
        
        //新欢
        //消费节点编号接着网络节点后面
        // mcmf_bak.addedge(consumeID+netStates,netStateID,need,0);
        mcmf_zkw_bak.AddEdge(netStateID,consumeID+netStates,need,0);
        //添加超汇到消费点的边
        // mcmf_bak.addedge(superSink, consumeID+netStates, need, 0);
        mcmf_zkw_bak.AddEdge(consumeID+netStates, superSink, need, 0);
    }
    mcmf_zkw_bak.k = totalFlow;
    //将边界节点加入初始种群
    population.push_back(borderNetStates);
    
    
    //添加初始解 即与消费节点相连的网络节点作为服务器
    minCost = consumeStates * serverPrice;
    //初始化结束 打印初始解--------------------------------
    // printInfo();
    // outputTXT();
    
    
}




//你要完成的功能总入口
void deploy_server(char * topo[MAX_EDGE_NUM], int line_num,char * filename)
{
    
    
    //记录程序开始时间
    start_time = clock();
    
    //另存结果输出位置
    outputFile = filename;
    
    //初始化
    init(topo);
    
    // cout<<netLinkInfo[0][0]<<"==="<<netLinkInfo[0][1]<<"==="<<netLinkInfo[0][2]<<"==="<<netLinkInfo[0][3]<<endl;
    // xjbs_forth();
    if(netStates<200){
	     TIME_OUT = 30;
	     anneal();
     }else{
	    if(netStates<400){
	     	TIME_OUT = 88;
	     }
     	xjbs_forth();
     }
    
    // xjbs();
    // xjbs_sec();
    /*while((clock()-start_time)/CLOCKS_PER_SEC<80){
     anneal();
     annealTime++;
     // break;
     }*/
    
    
    /*cout << "删除"<<a[1] <<" 增加"<< a[2] <<" 移动"<< a[3] <<" 替换"<< a[4] << endl;
    for (int i = 0; i < deleteTime.size(); i++) {
        cout << deleteTime[i] << " ";
    }
    cout <<endl<<"-----------------------------------------------------------------"<<endl;
    for (int i = 0; i < addTime.size(); i++) {
        cout << addTime[i] << " ";
    }
    cout <<endl<<"-----------------------------------------------------------------"<<endl;
    
    for (int i = 0; i < moveTime.size(); i++) {
        cout << moveTime[i] << " ";
    }
    cout <<endl;*/
    
    /*if (netStates < 200) {
        lastServerIndex = bestIds; // 计算几次的最小的情况
        cout << "best " << bestCost<< endl;
    }*/
    //搜索最小费用最大流路径 
    searchPath();
    // //输出最终程序结果
    outputTXT();
    
    // cout<<"退火循环次数："<<annealTime<<endl;
    cout<<"总花费时间："<<(clock()-start_time)/CLOCKS_PER_SEC<<endl;
    cout<<"总计算次数："<<totalComputeCount<<endl;
    // // 需要输出的内容
    // char * topo_file = "baoyou";
    
    // // 直接调用输出文件的方法输出到指定文件中(ps请注意格式的正确性，如果有解，第一行只有一个数据；第二行为空；第三行开始才是具体的数据，数据之间用一个空格分隔开)
    // write_result(topo_file, filename);
    
}
