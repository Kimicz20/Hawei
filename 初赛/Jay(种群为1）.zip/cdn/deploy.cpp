#include "deploy.h"
#include <queue>
#include <cstdio>
#include <algorithm>
#include <map>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cassert>
#include <string.h>
#include <string>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <set>

using namespace std;
const int INF = 0x3f3f3f3f;
const int TIME_OUT = 80;//设置超时时间

//节点需从0开始编号，从1开始编号的话，需更改fill函数和init
//struct MinCostFlow mcf_bak;//不变部分图备份
int n,m;//节点数，边数
int serversNum = 3;//服务器个数
vector<int> serverIndex;
int serverPrice; //服务器成本
int superSource,superSink;
int totalFlow=0;//总流量
int netStates,netRoutes,consumeStates;
int minCost ;

vector<string> lastPaths;//最终最短路径集合
set<int> lastServerIndex;//最终服务器节点
vector<set<int>> population;//可行服务器位置种群
vector<string> shortPaths;//最短路径集合

char * outputFile;//输出文件位置
set<int> borderNetStates;//与消费节点相邻的网络节点id
set<int> itServers;//每次迭代求解的服务器位置
set<int> tempServers;

clock_t start_time;//程序开始时间
bool timeout = false;//是否超时

struct MinCostFlow {
	static const int MAX_V = 2000;

	//first保存最短路径，second保存顶点编号
	typedef pair<int,int> P;

	//用于表示边的结构体（终点、容量、费用、反向边）
	struct edge {
		int to, cap, cost, rev;
	};
	//顶点数
	int V;
	//图的邻接表
	vector<edge> G[MAX_V];
	//顶点的势
	int h[MAX_V];
	//最短距离
	int dist[MAX_V];
	//最短路中的前驱节点和对应的边
	int prevv[MAX_V], preve[MAX_V];

	void add_edge(int from, int to, int cap, int cost) {
		G[from].push_back((edge) {
			to, cap, cost, G[to].size()
		});
		G[to].push_back((edge) {
			from, 0, -cost, G[from].size() - 1
		});
	}

	int min_cost_flow(int s, int t, int f) {
		shortPaths.clear();
		int res = 0;
		fill(h, h + V, 0); //初始化h  将每个节点的势初始化为0

		while (f > 0) {

			if((clock()-start_time)/CLOCKS_PER_SEC>TIME_OUT){
				return -1;
			}

			// Dijkstra更新h
			priority_queue<P, vector<P>, greater<P> > que;
			fill(dist, dist + V, INF);//将每个节点的最短距离赋值无穷大
			dist[s] = 0;
			que.push(P(0, s));

			while (!que.empty()) {
				P p = que.top();
				que.pop();
				int v = p.second;
				if (dist[v] < p.first)
					continue;

				for (int i = 0; i < G[v].size(); i++) {
					edge& e = G[v][i];
					if (e.cap > 0 && dist[e.to] > dist[v] + e.cost + h[v] - h[e.to]) {
						dist[e.to] = dist[v] + e.cost + h[v] - h[e.to];
						prevv[e.to] = v;
						preve[e.to] = i;
						que.push(P(dist[e.to], e.to));
					}
				}
			}

			//不能再增广了
			if (dist[t] == INF) {
				//更改 返回未满足的流量需求
				return -f;
				//return -1;
			}

			//程序执行到这里就拿到了一条最短路径


			for (int v = 0; v < V; v++) {
				h[v] +=  dist[v];
			}

			//从s到t的最短路尽量增广
			int d = f;
			vector<int> shortIndex;
			string path = "";
			//用剩余需求流量和最短路径中最小的容量比较，最小值为增广流量
			for (int v = t; v != s; v = prevv[v]) {
				d = min(d, G[prevv[v]][preve[v]].cap);

				//保存最短路径
				if(v!=t){
					shortIndex.push_back(v);
					
				}
			
			}
			for(int k=shortIndex.size()-1;k>=0;k--){
				char tm[6];
				if(k!=0){
					sprintf(tm,"%d",shortIndex[k]);
				}else{
					sprintf(tm,"%d",shortIndex[k]-netStates);
				}
				
				string t= tm;
				path += t+" ";
			}
			char tm[600];
			sprintf(tm,"%s%d",path.c_str(),d);
			path =  tm;
			shortPaths.push_back(path);


			f -= d;//分配给当前得到的最短路径的增广流量
			res += d * h[t];
			for (int v = t; v != s; v = prevv[v]) {
				edge &e = G[prevv[v]][preve[v]];
				e.cap -= d;
				//G[v][e.rev].cap += d;
			}

		}
		return res;
	}

	void init() {
		//这里假设节点从0编号
		for (int i = 0; i < V; i++) {
			G[i].clear();
		}
		V = 0;
	}

} mcf_bak ;



void printInfo(){
	cout<<"总需求："<<totalFlow<<endl<<"服务器位置：";
	// for(int k=0; k<lastServerIndex.size(); k++) {
	// 	cout<<lastServerIndex[k]<<"  ";
	// }
	for(set<int>::iterator it=lastServerIndex.begin();it!=lastServerIndex.end();++it){
		// cout<<*it<<"  ";
		cout<<*it<<",";
	}
	cout<<endl;

	printf("最小费用：%d\n",minCost);

	//输出文件
	cout<<lastPaths.size()<<endl<<endl;
	for(int k=0;k<lastPaths.size();k++){
		cout<<lastPaths[k]<<endl;
		
	}
}


void buildGraphAndSearch(){
	struct MinCostFlow mcf = mcf_bak;
	//添加超源到服务器的边
	for(set<int>::iterator it=itServers.begin();it!=itServers.end();++it){
		mcf.add_edge(superSource, *it, 600, 0);
		mcf.add_edge(*it, superSource, 600, 0);
	}
	
	int currCost = mcf.min_cost_flow(superSource, superSink, totalFlow);
	if(currCost>0&&currCost+serverPrice*itServers.size()<minCost) {
		minCost = currCost+serverPrice*itServers.size();
		lastPaths = shortPaths;
		lastServerIndex = itServers;
		set<int> goodServers(itServers);
		population.push_back(goodServers);
		if(population.size()>1){
			population.erase(population.begin());
		}
		
		// printInfo();

	}else{
		itServers = tempServers;
	}
}


int countx = 0;
void randelete(){
	srand((unsigned)time(NULL)+countx++);
	// cout<<"itservers.size:"<<itServers.size()<<endl;
	int r = rand()%(itServers.size());
	// cout<<"randeleter:"<<r<<endl;
	set<int>::iterator point= itServers.begin();
	while(r--){
		point++;
	}
	itServers.erase(point);
}

//筛选服务器点
void chooseServer(){
	//变化服务器节点之前先保存副本
	tempServers = itServers;

	randelete();
	srand((unsigned)time(NULL)+countx++);
	double ran = (double)rand()/RAND_MAX;
	// cout<<"r:"<<ran<<endl;
	if(ran>0.5){
		randelete();
	}

	srand((unsigned)time(NULL)+countx++);
	int r = rand()%(netStates);
	// cout<<"netStatesr:"<<r<<endl;
	itServers.insert(r);

}

void xjbs_sec(){
	
	itServers = borderNetStates;
	// clock_t end_time = clock();
	while(itServers.size()>consumeStates/4&&(clock()-start_time)/CLOCKS_PER_SEC<TIME_OUT){
		chooseServer();
		buildGraphAndSearch();
		
	}
}

/*void xjbs_sec(){
	
	// clock_t end_time = clock();
	while((clock()-start_time)/CLOCKS_PER_SEC<TIME_OUT){
		srand((unsigned)time(NULL));
		// cout<<"population.size:"<<population.size()<<endl;
		int r = rand()%(population.size());
		// cout<<"population:"<<r<<endl;
		itServers = population[r];

		// int count = netStates/3;
		int count = 66;
		while(count--){
			chooseServer();
			if(itServers.size()<consumeStates/4  || (clock()-start_time)/CLOCKS_PER_SEC>TIME_OUT){
				break;
			}
			buildGraphAndSearch();
		}
	}
}*/



void outputTXT(){
	 // string outstr = "";
           char outstr[16000];
           sprintf(outstr,"%d%s",lastPaths.size(),"\n\n");

           for(int k=0;k<lastPaths.size();k++){
		   		
				sprintf(outstr,"%s%s%s",outstr,lastPaths[k].c_str(),"\n");
			}

           //需要输出的内容
			char * topo_file = outstr;

			// 直接调用输出文件的方法输出到指定文件中(ps请注意格式的正确性，如果有解，第一行只有一个数据；第二行为空；第三行开始才是具体的数据，数据之间用一个空格分隔开)
			write_result(topo_file, outputFile);
}

//初始化 3.初始解 2.不变的部分图结构备份 1.各参数读取初始化
void init(char ** topo){
	//读取第一行
	// int lineNum = line_num;
	char* firstLine = topo[0];
	char* tmp;
	char t[256];
	char* tmp2;
	char* tmp3;
	tmp = strtok(firstLine," ");
	netStates = atoi(tmp);
	tmp = strtok(NULL," ");
	netRoutes = atoi(tmp);
	tmp = strtok(NULL," ");
	consumeStates = atoi(tmp);
	n = netStates+consumeStates+2;//总结点数 
	//m = netRoutes+consumeStates+serversNum+consumeStates;//总边数
	mcf_bak.V = n;
	//读取第三行
	char* thirdLine = topo[2];
	serverPrice = atoi(thirdLine);
	//读取第五行
	for(int i=4;i<4+netRoutes;i++){
		char* netLine = topo[i];
		tmp = strtok(netLine," ");
		int netState1 = atoi(tmp);
		tmp = strtok(NULL," ");
		int netState2 = atoi(tmp);
		tmp = strtok(NULL," ");
		int cap = atoi(tmp);
		tmp = strtok(NULL," ");
		int cost = atoi(tmp);

		mcf_bak.add_edge(netState1,netState2,cap,cost);
		mcf_bak.add_edge(netState2,netState1,cap,cost);

	}
	//读取剩下的消费节点信息行
	for(int i=5+netRoutes;i<5+netRoutes+consumeStates;i++){
		
		char* consumeLine = topo[i];
		// char* tmp2,tmp3;
		tmp = strtok(consumeLine," ");
		int consumeID = atoi(tmp);
		tmp2 = strtok(NULL," ");
		int netStateID = atoi(tmp2);
		borderNetStates.insert(netStateID);
		tmp3 = strtok(NULL," ");
		tmp3 = strtok(tmp3,"\n");
		int need = atoi(tmp3);

		totalFlow += need;

		sprintf(t,"%s %s %s",tmp2,tmp,tmp3);
		string oneRoute = t;
		lastPaths.push_back(oneRoute);//初始解路径


		mcf_bak.add_edge(consumeID+netStates,netStateID,need,0);
		mcf_bak.add_edge(netStateID,consumeID+netStates,need,0);
	}
	//将边界节点加入初始种群
	population.push_back(borderNetStates);
	//添加超级源点和超级汇点的信息
	superSource = netStates+consumeStates;
	superSink = superSource+1;
	//添加超汇到消费点的边
	for(int i=netStates ; i<netStates+consumeStates; i++) {
		mcf_bak.add_edge(superSink, i, 600, 0);
		mcf_bak.add_edge(i, superSink, 600, 0);
	}
	//添加初始解 即与消费节点相连的网络节点作为服务器
	minCost = consumeStates * serverPrice;
	//初始化结束 打印初始解--------------------------------
	// printInfo();
	// outputTXT();
	

}


//你要完成的功能总入口
void deploy_server(char * topo[MAX_EDGE_NUM], int line_num,char * filename)
{
	
	//记录程序开始时间
	start_time = clock();

	//另存结果输出位置
	outputFile = filename;
	
	//初始化
	init(topo);
	

	// xjbs();
	xjbs_sec();
	//输出最终程序结果
	outputTXT();

	// cout<<"总花费时间："<<(clock()-start_time)/CLOCKS_PER_SEC<<endl;
	// // 需要输出的内容
	// char * topo_file = "baoyou";

	// // 直接调用输出文件的方法输出到指定文件中(ps请注意格式的正确性，如果有解，第一行只有一个数据；第二行为空；第三行开始才是具体的数据，数据之间用一个空格分隔开)
	// write_result(topo_file, filename);

}
