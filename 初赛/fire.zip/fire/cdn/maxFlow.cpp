
#include "maxFlow.hpp"
#include <iostream>
#include <algorithm>
#include <string>
#include <sstream>
#include <set>
#include <vector>
#include <stack>
#include <map>
#include <queue>
#include <deque>
#include <stdio.h>
#include <cstring>
#include <cmath>
#include <ctime>
#include <stdlib.h>
#include <functional>

#define maxn 10000

using namespace std;




void MCMF_ZKW:: init(int n,int netNode,int consumeNode,int serverCost,map<int,pair<int,int> > serverLevel,vector<int> netStateDeployPrice){
    this->n = n;
    this->netNode= netNode;
    this->consumeNode= consumeNode;
    this->serverCost= serverCost;

    this->serverLevel= serverLevel;
    this->netStateDeployPrice = netStateDeployPrice;
    this->maxServerOutput = serverLevel.rbegin()->first;

    this->numOfserver = 0;
    
    this->s= netNode + consumeNode;
    this->t= this->s + 1;
    
    for(int i=0; i<n; i++)  res[i].clear(), outFlow.clear() ;
    memset(isNetToCons, -1 ,sizeof(isNetToCons));
    
    size = 0;
    memset(net, -1, sizeof(net));
}


void MCMF_ZKW:: AddEdge(int from , int to, int cap , int cost) {
    E.push_back(EDGE(to, cap, cost, net[from] , 0));
    net[from] = size++;
    E.push_back(EDGE(from, 0, -cost, net[to] , 0));
    net[to] = size++;
}



bool MCMF_ZKW:: adjust()
{
    int v, min = INF;
    for (int i = 0; i < n; i++)
    {
        if (!vis[i])
            continue;
        for (int j = net[i]; v = j == -1 ? 0 : E[j].v, j != -1; j = E[j].next) {
            if (E[j].cap > E[j].flow)
                if (!vis[v] && dis[v] - dis[i] + E[j].cost < min)
                    min = dis[v] - dis[i] + E[j].cost;
        }
    }
    if (min == INF)
        return false;
    for (int i = 0; i < n; i++)
        if (vis[i])
        {
            cur[i] = net[i];
            vis[i] = false;
            dis[i] += min;
        }
    return true;
}


int MCMF_ZKW:: augment(int i, int flow)
{


      if (t != i)
    {
        vis[i] = true;
        for (int j = cur[i], v; v = j == -1 ? 0 : E[j].v, j != -1; j = E[j].next) {
            if(E[j].cap <= E[j].flow) continue;
            if (vis[v] || dis[v] + E[j].cost != dis[i]) {
                continue;
            }

            conflow[i-netNode]+= v==t ? flow : 0;
            int delta = augment(v, std::min(flow, E[j].cap - E[j].flow));
            if (delta > 0)
            {
                E[j].flow = E[j].flow + delta;
                E[j ^ 1].flow = E[j ^ 1].flow - delta;
                cur[i] = j;
                return delta;
            }

        }
        return 0;
    } else {
        maxflow += flow;
        mincost += dis[s] * flow;
        return flow;
    }

    
}



   
int MCMF_ZKW:: zkw(int _s, int _t, int need)
{
    s = _s, t = _t;

    mincost = maxflow = 0;
    for (int i = 0; i < n; i++){
        vis[i] = false;
        cur[i] = net[i];
    }

    do
    {
        while (augment(s, INF))
            memset(vis, false, sizeof(vis));
        
    } while (adjust());
    if (maxflow < need)
        return -1;
  
    
    return addServerAndDeployPrice(mincost);
}

//通过服务器输出流量确定相应的档次价格
pair<int,int> MCMF_ZKW::determineDC(int serverOutput){
    map<int, pair<int,int> >::iterator iter;
   
    for(iter = serverLevel.begin() ; iter != serverLevel.end(); iter++){
        if(serverOutput<=iter->first){
            return iter->second;
        }
    }
    return serverLevel.rbegin()->second;
}

  

//确定并加上不同档次服务器和网络节点部署的费用
int MCMF_ZKW::addServerAndDeployPrice(int cost){
    
        
        int total = 0;
            
            // v = j == -1 ? 0 : E[j].v, j != -1
        for (int i = net[s] , v; v = (i==-1?0:E[i].v), i != -1; i = E[i].next){
            
            
            if(E[i].flow>0) {  //搜路径 ,初始为服务点
                   
                int serverOutput = 0;
                
                for (int j = net[v] ; j != -1; j = E[j].next){
            
                    if(E[j].flow>0) {
                        serverOutput += E[j].flow;
                        
                    } 

                    
                }
                if(serverOutput>maxServerOutput){
                    serverOutput = maxServerOutput;
                }
                total += serverOutput;
                int serverFee = determineDC(serverOutput).second;
                // cout<<"服务器："<<v<<"总输出："<<serverOutput<<"对应的服务器费用："<<serverFee<<endl;
                cost += (serverFee + netStateDeployPrice[v]);


            }
        }
        
            // cout<<"total he k:"<<total<<"he"<<k<<endl;
        
        
        return cost;
}
    
//确定存储每个服务器的档次
void MCMF_ZKW::storeServerGrade(){
    
    

    for(int i=0; i< outCnt ;i++){
        int j= (int)res[i].size()-1 ; 
        
        int serverIndex = res[i][j];
        
        map<int, int>::iterator iter = server_dc_map.find(serverIndex);    
        if(iter!=server_dc_map.end()){
            // cout<<"iter->second加之前："<<iter->second;
            iter->second += outFlow[i];
            // cout<<"iter->second加之后："<<iter->second<<"加了多少："<<outFlow[i]<<endl;
        }else{
            server_dc_map.insert(pair<int,int>(serverIndex,outFlow[i]));
        }
    }
    map<int, int>::iterator iter;
    int totalFeed = 0;
    for(iter = server_dc_map.begin() ; iter != server_dc_map.end(); iter++){
        totalFeed += iter->second;
        // cout<<iter->first<<"攻击"<<iter->second<<endl;
        pair<int,int> p = determineDC(iter->second);
        iter->second = p.first;
    }
    cout<<"总供给："<<totalFeed<<endl;
    cout<<"总需求："<<k<<endl;
}


void MCMF_ZKW:: OutputPath(string& str){

        storeServerGrade();

        char c[50];
        
       // printf("outCnt = %d\n\n", outCnt);
        sprintf(c, "%d\n\n", outCnt);
        str += c;
        
        for(int i=0; i< outCnt ;i++){
            for(int j= (int)res[i].size()-1 ; j>0; j--)
            {
         //       printf("%d ",res[i][j]>=netNode?(res[i][j]-netNode):res[i][j]);
                sprintf(c,"%d ",res[i][j]>=netNode?(res[i][j]-netNode):res[i][j]);
                str +=c;
            }
           // printf("%d\n",outFlow[i]);
            int j= (int)res[i].size()-1 ; 
        
            int serverIndex = res[i][j];
            sprintf(c, "%d %d\n",outFlow[i],server_dc_map[serverIndex]);
            str +=c;
        }
    }



    void MCMF_ZKW:: update_flow(int minflow , int fa[]){
        //从s开始
        int cnt = outCnt;
        // printf("cnt=%d: minflow=%d\n",cnt, minflow);
        int u=t;
        while(u!=s){
            
            //流量更新，减掉minflow
            //  if(p[u]==s) printf("p_edeg=%d ,s.flow=%d ",p_edge[u], edges[p_edge[u]].flow);
            //edges[p_edge[u]].flow -=minflow;
            E[p_edge[u]].flow -=minflow;
            if(u != s) res[cnt].push_back(u);
            //   if(p[u]==s) printf("^^^^ , s.flow=%d \n",edges[p_edge[u]].flow);
            u = fa[u];
        }
        outFlow.push_back(minflow);
        
        
        find_flow += minflow;
        outCnt++;
    }


//cur表示当前点
void MCMF_ZKW:: dfs_findPath(int cur, int minflow){
    
    if(ok) return;
    
    //从s正方向找
    if(cur == t){
        
        //更新整条路上的 流量
        update_flow(minflow, fa);
        ok=1;
        return ;
    }
    // v = j == -1 ? 0 : E[j].v, j != -1
    for (int i = net[cur] , v; v = E[i].v, i != -1; i = E[i].next){
        
        if(E[i].flow<=0) continue; //反向边不搜索
        if(find_vis[v]) continue;
        
        fa[v] = cur;
        p_edge[v] = i;
        find_vis[v] = 1;
        
        if(cur ==0 && E[i].v==119)
        {
            //printf("cur=%d , i= %d , E[i].flow =%d\n",cur, i ,E[i].flow);
         //   while (1) {
          //      printf("cao");
          //  }
        }
        dfs_findPath(v , min(minflow, E[i].flow));
        
        find_vis[v] = 0;
        
        if(ok) return;
        
    }
    
}




    void MCMF_ZKW::search_path(){

        printf("search start\n");
        outCnt = 0;
        for(int i=0; i<1500;i++)
        {
            res[i].clear();
            outFlow.clear();
        }
        find_flow = 0;
        fa[s] = -1;
        while(find_flow< k ){
            
            // for(int i=0; i<(int)G[st].size(); i++){
            for (int i = net[s] , v; v = E[i].v, i != -1; i = E[i].next){
                //puts("ss");
                // printf("i=%d, e.flow =%d e.from =%d, e.to =%d\n",i, e.flow , e.flow , e.to);
                fa[v] = s;
                p_edge[v] = i;
                
                if(E[i].flow>0) {  //搜路径 ,初始为服务点
                    ok=0;
                    memset(find_vis, 0, sizeof(find_vis));
                    find_vis[s] = 1;
                    dfs_findPath(v , INF);
                  //   printf("find_flow =%d , k=%d\n",find_flow, k);
                }
                
                
            }
        }
    }

