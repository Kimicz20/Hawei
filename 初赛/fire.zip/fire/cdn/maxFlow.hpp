

#ifndef maxFlow_hpp
#define maxFlow_hpp

#include<iostream>
#include<algorithm>
#include<string>
#include<sstream>
#include<set>
#include<vector>
#include<stack>
#include<map>
#include<queue>
#include<deque>
#include<cstdlib>
#include<stdio.h>
#include<cstring>
#include<cmath>
#include<ctime>
#include<functional>
#define maxn 10000
#define INF 100000000

using namespace std;


int maxFlow(struct MCMF_ZKW& hua);

struct EDGE
{
    int v, cap, cost, next ,flow;
    EDGE() {}
    EDGE(int a, int b, int c, int d ,int e)
    {
        v = a, cap = b, cost = c, next = d;
        flow = e;
    }
};

struct Node{
    int f,indx;
    double averCost;
};


struct MCMF_ZKW{
    //保存服务器档次信息
    map<int,pair<int,int> > serverLevel;
    vector<int> netStateDeployPrice;//网络节点部署成本
    int maxServerOutput;//最大档次服务器输出
    map<int,int> server_dc_map;//服务器_档次map
    
    int k;
    int serverCost, netNode , consumeNode,numOfserver;
    
    int size, n;
    int s, t, maxflow, mincost;
    bool vis[maxn];
    int net[maxn], pre[maxn], cur[maxn], dis[maxn];
    std::queue <int> Q;
    
    vector<struct EDGE> E;
    
    int pointFlow;
    
    vector<int> res[maxn]; 
    vector<int> outFlow;  
    int outCnt; 
    
    
    int fa[2000];
    int find_flow;
    int p_edge[2000]; 
    int ok;
    int find_vis[2000];
    
    struct Node degree[maxn]; 
    int consumeEdge[2000]; 
    int consumeFlow[2000];  
    int isNetToCons[2000];
    
    int costNow;
    int consumeMaxFlow;
    
    
    
    int conflow[2000], conflowNeed[2000];
    
    
    void init(int n,int netNode,int consumeNode,int serverCost,map<int,pair<int,int> > serverLevel,vector<int> netStateDeployPrice);
    void AddEdge(int from , int to, int cap , int cost) ;
    bool adjust();
    int augment(int i, int flow);
    int zkw(int _s, int _t, int need);
    

    pair<int,int> determineDC(int serverOutput);
    int addServerAndDeployPrice(int cost);
    void storeServerGrade();

    void search_path();
    void update_flow(int minflow , int fa[]);
    void dfs_findPath(int cur, int minflow);
    void OutputPath(string& str);
  
};

#endif 
