package com.cacheserverdeploy.deploy;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Graph {
	
	public Node[] nodeList;//顺序按照点的编号升序
	//边的信息，还是用一个邻接矩阵来存吧
	public int[][] bandwith;//带宽
	public int[][] bandcost;//带宽费用
	private int maxlimit;
	private Node superdest;
	private Node supersource;
	private int nodeSum;
	
	public Graph(Node[] nodeList, int[][] bandwith, int[][] bandcost,int maxlimit, Node superdest, Node supersource, int nodeSum) {
		this.nodeList = nodeList;
		this.bandwith = bandwith;
		this.bandcost = bandcost;
		this.maxlimit = maxlimit;
		this.superdest = superdest;
		this.supersource = supersource;
		this.nodeSum = nodeSum;
	}

	//sourceCost,searchSet,searchband,prev 传入的参数已初始化,初始邻接信息,带路径,最小费用
	public boolean dijstra(int[] sourceCost,Set<Integer> searchSet,int[][]searchband,int[] prev, int size,Node source,Node destination ) {
		int minIndex=maxlimit,min=maxlimit;
		if(searchSet.isEmpty()) return false;
		while(!searchSet.isEmpty()){
			min=maxlimit;
			//最小边和节点
			for(Integer i : searchSet){
				if(sourceCost[i]<min) {
					min=sourceCost[i];
					minIndex=i;
				}
			}
			searchSet.remove(minIndex);//从搜索集移除
			//设置最小边节点的总花费
			Node minNode=nodeList[minIndex];
			for(Node nn:minNode.adjNodes){
				if(searchband[minIndex][nn.nodeNo]<=0) continue;
				int mindis=sourceCost[minIndex]+bandcost[minIndex][nn.nodeNo];
				if(mindis<sourceCost[nn.nodeNo]) {
					prev[nn.nodeNo]=minIndex;//设置前驱
					sourceCost[nn.nodeNo]=mindis;//更新最小花费的值
					searchSet.add(nn.nodeNo);//加入搜索集
				}
			}
			//直到最小边已扩展到终点
			if(minIndex==destination.nodeNo) {
				return true;
			}
		}
		return false;
	}
	//sourceCost,searchSet,searchband,prev 传入的参数已初始化,初始邻接信息,带路径,最大流
	public boolean dijstraMax(int[] sourceCost,Set<Integer> searchSet,int[][]searchband,int[] prev, int size,Node source,Node destination ) {
		int maxIndex=maxlimit,max=0;
		if(searchSet.isEmpty()) return false;
		while(!searchSet.isEmpty()){
			max=0;
			//最大流边和节点
			for(Integer i : searchSet){
				if(sourceCost[i]>max) {
					max=sourceCost[i];
					maxIndex=i;
				}
			}
			searchSet.remove(maxIndex);//从搜索集移除
			//设置最大边节点的总花费
			Node maxNode=nodeList[maxIndex];
			for(Node nn:maxNode.adjNodes){
				if(searchband[maxIndex][nn.nodeNo]<=0) continue;
				int maxdis=sourceCost[maxIndex]>bandwith[maxIndex][nn.nodeNo]?sourceCost[maxIndex]:bandwith[maxIndex][nn.nodeNo];
				if(maxdis>sourceCost[nn.nodeNo]) {
					prev[nn.nodeNo]=maxIndex;//设置前驱
					sourceCost[nn.nodeNo]=maxdis;//更新最大流的值
					searchSet.add(nn.nodeNo);//加入搜索集
				}
			}
			//直到最大边已扩展到终点
			if(maxIndex==destination.nodeNo) {
				return true;
			}
		}
		return false;
	}
	
	public Long minCost(Node source,Node destination,List<Route> routes,boolean routeFlag){
		int size= nodeSum+2;//节点个数,加入超级元
		int maxband=destination.cNode.consumBand;//消费节点的带宽
		int[][] sourceband=new int[size][];//带宽的邻接矩阵，不临接的设无穷大10000000，用克隆避免更改原始数据,待优化
		for(int i=0,j=bandwith.length;i<j;i++){
			sourceband[i]=bandwith[i].clone();
		}
		int[] prev=new int[size];//当前节点的前驱
		Set<Integer> nodeSet=new HashSet<>();//待访问节点集。
		long minCost=0;
		LinkedList<Integer> list=null;
		if(routeFlag) list=new LinkedList<>();
		
		while (maxband>0) {
			int[] sourceCost=bandcost[source.nodeNo].clone();//source到其余节点的最大花费，没拓展到的设无穷大
			nodeSet.clear();//清空待访问集
			//初始化一些sourceCost，nodeSet，prev
			for(Node nn:source.adjNodes){
				if(sourceband[source.nodeNo][nn.nodeNo]<=0) sourceCost[nn.nodeNo]=maxlimit;
				else {
					nodeSet.add(nn.nodeNo);
					prev[nn.nodeNo]=source.nodeNo;
				}
			}
			//dijstra,无值返回null	
			boolean flag=dijstra(sourceCost, nodeSet, sourceband, prev, size, source, destination);
			if(flag==false) return null;
			
			//更新边的信息
			int indexx=destination.nodeNo;//终点
			int bandmin=maxlimit;//路径中的最小带宽
			//直到前驱是起点 
			while(indexx!=source.nodeNo){
				int temp=sourceband[prev[indexx]][indexx];
				if(temp<bandmin) bandmin=temp;
				indexx=prev[indexx];
			}
			indexx=destination.nodeNo;
			if(maxband<bandmin) bandmin=maxband;
			while(indexx!=source.nodeNo){
				int temp=prev[indexx];
				sourceband[temp][indexx]-=bandmin;//最小路径上的每条边的带宽都减去最小带宽
				indexx=temp;
			}
			maxband-=bandmin;//消费节点带宽减去当前最小带宽
			minCost+=sourceCost[destination.nodeNo]*bandmin;
			
			//得到路径
			if(routeFlag){
				list.clear();
				indexx=destination.nodeNo;
				{//这一步专门为超级元设置，不加超级元
					indexx=prev[indexx];
					list.addFirst(nodeList[indexx].cNode.nodeNo);
				}
				while(indexx!=source.nodeNo){
					list.addFirst(indexx);
					indexx=prev[indexx];
				}
				//这一步专门为超级元设置,注释掉，，不加超级元
//				list.addFirst(indexx);
				
				LinkedList<Integer> llist=(LinkedList<Integer>)list.clone();
				routes.add(new Route(llist,bandmin));
			}
		}
		
		return minCost;
	}
	
	//设置成超级元的样子，就可以解决多源多汇，输入服务器节点,不带路径
	public Long minCost(List<Node> sources) {
		int ss=supersource.nodeNo;
		//初始化超级元
		supersource.clearAdj();
		for(Node e:sources){
			supersource.addAdj(e);
		}
		for(int i=0,j=nodeSum+2;i<j;i++){
			bandwith[ss][i]=0;
			bandcost[ss][i]=maxlimit;
		}
		for(Node n:sources){
			bandwith[ss][n.nodeNo]=maxlimit;
			bandcost[ss][n.nodeNo]=0;
		}
		
		return minCost(supersource, superdest,null,false);
	}
	//设置成超级元的样子，就可以解决多源多汇，输入服务器节点,不带路径
	public Long minCostWithRoute(List<Node> sources,List<Route> routes) {
		int ss=supersource.nodeNo;
		//初始化超级元
		supersource.clearAdj();
		for(Node e:sources){
			supersource.addAdj(e);
		}
		for(int i=0,j=nodeSum+2;i<j;i++){
			bandwith[ss][i]=0;
			bandcost[ss][i]=maxlimit;
		}
		for(Node n:sources){
			bandwith[ss][n.nodeNo]=maxlimit;
			bandcost[ss][n.nodeNo]=0;
		}
		
		return minCost(supersource, superdest,routes,true);
	}

}
