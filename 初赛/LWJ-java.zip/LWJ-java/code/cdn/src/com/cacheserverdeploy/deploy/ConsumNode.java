package com.cacheserverdeploy.deploy;

public class ConsumNode {
	public int nodeNo;
	public int consumBand;
	
	public ConsumNode(int nodeNo, int consumBand) {
		this.nodeNo = nodeNo;
		this.consumBand = consumBand;
	}
	
}
