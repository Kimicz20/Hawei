package com.cacheserverdeploy.deploy;

import java.util.ArrayList;
import java.util.List;

public class Node {
	public int nodeNo;//点的编号
	public ConsumNode cNode;//如果是消费节点，有个消费带宽
	public ArrayList<Node> adjNodes;//相邻的点
	
	
	public Node(int nodeNo, ArrayList<Node> adjNodes) {
		this.nodeNo = nodeNo;
		this.adjNodes = adjNodes;
		this.cNode=null;
	}

	public boolean addAdj(Node e) {
		return adjNodes.add(e);
	}
	
	public void clearAdj() {
		adjNodes.clear();
	}
}
