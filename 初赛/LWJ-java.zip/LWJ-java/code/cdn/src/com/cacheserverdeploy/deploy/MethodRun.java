package com.cacheserverdeploy.deploy;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MethodRun {
	private int[][] netBands;
	private int[][] netCost;
	private Node superdest;//消费超级元
	private Node supersource;//服务超级元
	private Node[] nodeList;
	private int nodeSum;
	private int linkSum;
	private int conSum;
	private int serCost;
	private int maxlimit=10000000;
	private List<Route> routes;
	
	public MethodRun() {
	}

	public void input(String[] graphContent) {
		int insize=graphContent.length;
		String[] temp=graphContent[0].split(" ");//网络节点数量 网络链路数量 消费节点数量
		this.nodeSum=Integer.parseInt(temp[0]);
		this.linkSum=Integer.parseInt(temp[1]);
		this.conSum=Integer.parseInt(temp[2]);
		netBands=new int[nodeSum+2][nodeSum+2];//设置带宽，初始置0
		netCost=new int[nodeSum+2][nodeSum+2];//设置带宽花费，初始置无穷
		for(int i=nodeSum+1;i>=0;i--){
			for(int j=nodeSum+1;j>i;j--){
				netCost[i][j]=maxlimit;
			}
			netCost[i][i]=0;
			for(int j=i-1;j>=0;j--){
				netCost[i][j]=maxlimit;
			}
		}
		
		nodeList=new Node[nodeSum+2];
		this.serCost=Integer.parseInt(graphContent[2]);//视频内容服务器部署成本
		//链路起始节点ID 链路终止节点ID 总带宽大小 单位网络租用费
		int index=4;
		String str=graphContent[index];
		ArrayList<Node> ls=new ArrayList<>();
		while(str.length()>2){
			temp=str.split(" ");
			int a=Integer.parseInt(temp[0]);
			int b=Integer.parseInt(temp[1]);
			int c=Integer.parseInt(temp[2]);
			int d=Integer.parseInt(temp[3]);
			netBands[a][b]=netBands[b][a]=c;
			netCost[a][b]=netCost[b][a]=d;
			if(nodeList[b]==null) nodeList[b]=new Node(b, (ArrayList<Node>)ls.clone());
			if(nodeList[a]==null) nodeList[a]=new Node(a, (ArrayList<Node>)ls.clone());
			nodeList[a].addAdj(nodeList[b]);
			nodeList[b].addAdj(nodeList[a]);
			index++;
			str=graphContent[index];
		}
		//消费节点ID 相连网络节点ID 视频带宽消耗需求
		this.superdest=new Node(nodeSum, (ArrayList<Node>)ls.clone());
		nodeList[nodeSum]=this.superdest;
		index++;
		int maxConsum=0;
		while(index<insize){
			str=graphContent[index];
			temp=str.split(" ");
			int a=Integer.parseInt(temp[0]);
			int b=Integer.parseInt(temp[1]);
			int c=Integer.parseInt(temp[2]);
			nodeList[b].cNode=new ConsumNode(a,c);
			superdest.addAdj(nodeList[b]);
			nodeList[b].addAdj(superdest);
			maxConsum+=c;
			index++;
		}
		this.superdest.cNode=new ConsumNode(1, maxConsum);
		//初始化netBands，netCost，superdest，这些
		this.supersource=new Node(nodeSum+1, (ArrayList<Node>)ls.clone());
		nodeList[nodeSum+1]=this.supersource;
		
		for(Node n:superdest.adjNodes){
			netBands[n.nodeNo][superdest.nodeNo]=n.cNode.consumBand;
			netCost[n.nodeNo][superdest.nodeNo]=0;
		}
		
	}
	
	public String[] output() {
		if(routes==null||routes.size()<1) return new String[]{"NA"};
		int size=routes.size();
		StringBuffer sb=new StringBuffer();
		String[] Content=new String[size+2];
		Content[0]=String.valueOf(size);//路径个数
		Content[1]="";
		size=2;
		for(Route r:routes){
			for(Integer i:r.nodes){//服务器到消费节点
				sb.append(i+" ");
			}
			sb.append(r.bandwith);//最后添加带宽
			Content[size]=sb.toString();
			size++;
			sb.setLength(0);
		}
		return Content;
	}
	
	
	public void run() {
		Graph ga=new Graph(nodeList, netBands, netCost, maxlimit, superdest, supersource, nodeSum);
		
//		routes=new ArrayList<>();
//		List<Node> sources=new ArrayList<>();
//		for(int i=0,j=superdest.adjNodes.size();i<j;i++){
//			sources.add(nodeList[i]);
//		}
//		ga.minCost(sources);
//		sources=new ArrayList<>();
//		for(int i=1,j=superdest.adjNodes.size();i<=j;i++){
//			sources.add(nodeList[nodeSum-i]);
//		}
//		for(int i=0;i<nodeSum;i++){
//			sources.add(nodeList[i]);
//		}
//		ga.minCostWithRoute(sources, routes);
		
//		//确定优选集/*
//		final int[] bandlist=new int[nodeSum];
//		List<Node> nList=new ArrayList<>(nodeSum);
//		for(int i=0;i<nodeSum;i++){
//			int bandsum=0;
//			for(Node n:nodeList[i].adjNodes){
//				bandsum+=netBands[n.nodeNo][i];//流入量
//			}
//			bandlist[i]=bandsum;
//			nList.add(nodeList[i]);
//		}
//		nList.removeAll(superdest.adjNodes);
//		nList.sort(new Comparator<Node>() {
//			//降序
//			public int compare(Node o1, Node o2) {
//				if(bandlist[o1.nodeNo]>bandlist[o2.nodeNo]) return -1;
//				if(bandlist[o1.nodeNo]<bandlist[o2.nodeNo]) return 1;
//				else return 0;
//			}
//		});
//		int genLen=nList.size()/2+conSum;//大流量节点一半和消费节点和
//		int[] sourceList=new int[genLen];
//		//先加入消费节点
//		int num=0;
//		for(Node n:superdest.adjNodes){
//			sourceList[num]=n.nodeNo;
//			num++;
//		}
//		//再加入大流量节点
//		int i=0;
//		while (num<genLen){
//			sourceList[num++]=nList.get(i++).nodeNo;
//		}
		
//		//第二种方案
//		int genLen=nodeSum;
//		int[] sourceList=new int[genLen];
//		//先加入消费节点
//		int num=0;
//		for(Node n:superdest.adjNodes){
//			sourceList[num]=n.nodeNo;
//			num++;
//		}
//		List<Node> llList=new ArrayList<>();
//		for(int i=0;i<nodeSum;i++){
//			llList.add(nodeList[i]);
//		}
//		llList.removeAll(superdest.adjNodes);
//		for(Node n:llList){
//			sourceList[num++]=n.nodeNo;
//		}
//		llList=null;
		
		//第三种方案
		int genLen=nodeSum;
		int[] sourceList=new int[genLen];//全编码
		for(int i=0;i<nodeSum;i++){
			sourceList[i]=i;
		}
		
		//遗传
		Inheritance algo=new Inheritance(genLen, ga, nodeList, sourceList, serCost,conSum);
		algo.firstGen(superdest);
		algo.run();
		this.routes=algo.minRoutes;
	}

}
