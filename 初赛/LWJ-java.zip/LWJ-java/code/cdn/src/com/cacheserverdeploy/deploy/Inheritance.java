package com.cacheserverdeploy.deploy;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Inheritance {
	
	private int popSize = 20;//种群数量              
    private int maxiter = 100;//迭代次数
    private double crossP = 0.8;//交叉概率
    private double mutateP = 0.05;//变异概率
    
    private Gene[] group=new Gene[popSize];//群体
    private int genLen;//基因长度
    private class Gene {
    	public boolean code[];//单个基因的编码序列
        public Long fitness;//该基因的适应度
        public double selectP;//选择概率
        public int expect;//期望
		public Gene(boolean[] code) {
			this.code=code;
			this.fitness=null;
			this.selectP=0;
			this.expect=0;
		}
		//source
		public void copy(Gene source) {
			for(int i=0;i<genLen;i++){
				this.code[i]=source.code[i];
			}
			this.fitness=source.fitness;
			this.selectP=source.selectP;
			this.expect=source.expect;
		}
    }
    
    private Graph graph;//连通图
    private Node[] nodeList;//网络节点列表
    private int[] sourceList;//服务器节点列表，存储待选择的服务器节点编号
    public List<Route> minRoutes;//路径
    public Gene minGene;
    private long[] results=new long[10];//局部最优解,10个
    private int deployCost;
    private int conSum;//消费节点数
    private List<Integer> selectlist=new ArrayList<>();
	private LinkedList<Integer> noSelect=new LinkedList<>();
	private List<Node> sources=new ArrayList<>();
    
    /*
     * 初始化，构造种群
     */
	public Inheritance(int genLen, Graph graph, Node[] nodeList, int[] sourceList, int deployCost,int conSum) {
		this.genLen = genLen;
		this.graph = graph;
		this.nodeList = nodeList;
		this.sourceList = sourceList;
		this.deployCost = deployCost;
		this.conSum = conSum;
		this.minGene=new Gene(new boolean[genLen]);
	}
	/*
	 * 初代种群构建，粗糙的
	 */
	public void firstGen(Node superdest) {
		boolean[] codes=new boolean[genLen];
		
		for(Node n:superdest.adjNodes){
			codes[n.nodeNo]=true;
		}
		group[0]=new Gene(codes);
		
		firstGen2(superdest);
	}
	public void firstGen1() {
		boolean[] codes;
		//代表在sourcelist的编号
		int[] nodeIndex=new int[genLen];
		for(int i=0;i<genLen;i++){
			nodeIndex[i]=i;
		}
		
		for(int i=1;i<popSize;i++){
			codes=new boolean[genLen];
			int sum=genLen;
			int codeLen;
			if(conSum<200)
				codeLen=(int)(Math.random()*conSum/2+conSum/2+1);//限制数量？？比如4-9而不是0-9
			else
				codeLen=(int)(Math.random()*50+conSum-50+1);
			
			int temp;
			for(int j=0;j<codeLen;j++){
				int index=(int)(Math.random()*sum);
				int t=nodeIndex[index];
				codes[t]=true;
				temp=nodeIndex[index];
				nodeIndex[index]=nodeIndex[sum-1];
				nodeIndex[sum-1]=temp;
				sum--;
			}
			group[i]=new Gene(codes);
		}
	}
	public void firstGen2(Node superdest) {
		boolean[] codes=group[0].code;
		for(int i=1;i<popSize;i++){
			codes=codes.clone();
			int index=(int)Math.random()*conSum;
			int no=0;
			while(index>0){
				if(codes[no]) index--;
				no++;
				if(no>=genLen) no=0;
			}
			no--;
			if(no<0) no=genLen-1;
			codes[no]=false;
			int size=nodeList[no].adjNodes.size();
			int len=(int)(Math.random()*size);
			int selno=nodeList[no].adjNodes.get(len).nodeNo;
			while(selno>=genLen){
				if(len==0) len=size;
				selno=nodeList[no].adjNodes.get(--len).nodeNo;
			}
			if(!codes[selno]) codes[selno]=true;
			
			group[i]=new Gene(codes);
		}
		
	}
	
	/*
     * 交叉
     */
    public void cross() {
		int sum=(int)(popSize*crossP/2);
		int consum=conSum-1;
		boolean temp;
		while(sum>0){
			int sing1=(int)(Math.random()*popSize);//个体编号
			int sing2=(int)(Math.random()*popSize);//个体编号
			int x=(int)(Math.random()*genLen);//基因位置
			int y=(int)(Math.random()*genLen);//基因长度
			int sin1sum=0,sin2sum=0;
			while(y>0){
				temp=group[sing1].code[x];
				group[sing1].code[x]=group[sing2].code[x];
				group[sing2].code[x]=temp;
				x++;
				if(x>=genLen) x=0;
				y--;
			}
			//检查基因中true个数不超过conSum;
			for(int i=0;i<genLen;i++){
				if(group[sing1].code[i]) sin1sum++;
				if(group[sing2].code[i]) sin2sum++;
			}
			int index=0;
			while(sin1sum>consum){
				int l=(int)(Math.random()*genLen);
				index=(index+l>=genLen)?index+l-genLen:index+l;
				if(group[sing1].code[l]) group[sing1].code[l]=false;
				else continue;
				sin1sum--;
			}
			index=0;
			while(sin2sum>consum){
				int l=(int)(Math.random()*genLen);
				index=(index+l>=genLen)?index+l-genLen:index+l;
				if(group[sing2].code[index]) group[sing2].code[index]=false;
				else continue;
				sin2sum--;
			}
			sum--;
		}
	}
    /*
     * 变异
     */
    public void mutate(){
    	for(int i=0;i<popSize;i++){
    		double mm=Math.random();
    		if(mm<mutateP){
    			int posi=(int)(Math.random()*conSum/10)+1;
    			int insi=posi;
    			int index=(int)(Math.random()*genLen);
    			while(posi>0||insi>0){
    				if(group[i].code[index]) {
    					if(posi>0){
	    					group[i].code[index]=false;
	    					posi--;
    					}
    				}
    				else{
    					if(insi>0){
	    					group[i].code[index]=true;
	    					insi--;
    					}
    				}
    				index++;
    				if(index>=genLen) index=0;
    			}
    		}
    	}
    }
    /*
     * 适应度函数
     * x为group中的个体编号
     */
    public Long comFintness(int x) {
    	this.sources.clear();
    	int sum=0;
    	for(int i=0;i<genLen;i++){
    		if(group[x].code[i]){
    			sources.add(nodeList[sourceList[i]]);
    			sum++;
    		}
    	}
    	if(sources.isEmpty()) return null;
    	Long result=graph.minCost(sources);
    	if(result==null) return null;
    	else return result+sum*deployCost;
	}
    public Long comFintness(int x,List<Route> list) {
    	this.sources.clear();
    	int sum=0;
    	for(int i=0;i<genLen;i++){
    		if(group[x].code[i]){
    			sources.add(nodeList[sourceList[i]]);
    			sum++;
    		}
    	}
    	if(sources.isEmpty()) return null;
    	Long result=graph.minCostWithRoute(sources, list);
    	if(result==null) return null;
    	else return result+sum*deployCost;
	}
    /*
     * 计算群体选择概率
     */
    public void comSelect() {
    	double sum=0;
    	double psum=0;
		for(int i=popSize-1;i>=0;i--){
			if(group[i].fitness!=null)
				sum+=group[i].fitness;
		}
		for(int i=popSize-1;i>=0;i--){
			if(group[i].fitness!=null) {
				group[i].selectP=sum/group[i].fitness;
				psum+=group[i].selectP;
			}
		}
		for(int i=popSize-1;i>=0;i--){
			if(group[i].fitness!=null){
				group[i].selectP=group[i].selectP/psum;
				group[i].expect=(int)(group[i].selectP*popSize);
			}
		}
	}
    /*
     * 产生下一代种群
     */
    public void nextGroup() {
    	this.selectlist.clear();//清空
    	this.noSelect.clear();//清空
		for(int i=0;i<popSize;i++){
			if(group[i].expect>=1){
				selectlist.add(i);
			}
			else noSelect.add(i);
		}
    	selectlist.sort(new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				if(group[o1].fitness>group[o2].fitness) return 1;
				else if(group[o1].fitness<group[o2].fitness) return -1;
				else return 0;
			}
		});
		//选入下一种群
		for(Integer g:selectlist){
			int num=group[g].expect;
			group[g].expect=0;
			group[g].selectP=0;
			group[g].fitness=null;
			num--;
			while(num>0){
				Integer i=noSelect.removeLast();
				group[i].copy(group[g]);
				num--;
			}
		}
		//填充剩余的个体
		int index=0;
		int size=selectlist.size();
		while(!noSelect.isEmpty()){
			Integer i=noSelect.removeLast();
			group[i].copy(group[selectlist.get(index)]);
			index++;
			if(index>=size) index=0;
		}
	}
    
    public void validateGroup(){
    	int num=0;
    	for(int i=0;i<popSize;i++){
    		if(group[i].fitness==null) num++;
    	}
    	System.out.println("不合格个体数"+num);/////////////////////////////
    }
    /*
     * 终止条件
     */
    public boolean end(){
    	for(int i=0;i<9;i++){
    		double xx=results[i]-results[i+1];
    		xx=xx/minGene.fitness;
    		if(xx>0.01||xx<-0.01) return false;
    	}
    	return true;
    }

    public void run() {
    	long curt1=System.currentTimeMillis();
		int iter=0;
		int rindex=0;
		Gene curminGen=null;
		//计算第一代群体适应度
		Long minCost=null;
		for(int i=0;i<popSize;i++){
			group[i].fitness=comFintness(i);
			if(group[i].fitness!=null){
				if(minCost==null) {
					minCost=group[i].fitness;
					curminGen=group[i];
				}
				else if(group[i].fitness<minCost){
					minCost=group[i].fitness;
					curminGen=group[i];
				}
			}
		}
		validateGroup();///////////////////////////////
//		System.out.println(minGene.code.length);//////////////////////
		minGene.copy(curminGen);
		results[rindex++]=curminGen.fitness;
		System.out.println("初种群最优秀:"+minGene.fitness);///////////////////////
		//循环迭代
		while(iter<maxiter){
//			System.out.println("第"+iter+"代-----------");//////////////////////
			//交叉变异
			cross();
			mutate();
//			System.out.println("交叉变异完成");////////////////////
			//计算群体适应度
			minCost=null;
			for(int i=0;i<popSize;i++){
				group[i].fitness=comFintness(i);
				if(group[i].fitness!=null){
					if(minCost==null) {
						minCost=group[i].fitness;
						curminGen=group[i];
					}
					else if(group[i].fitness<minCost){
						minCost=group[i].fitness;
						curminGen=group[i];
					}
				}
			}
			validateGroup();//////////////////////////////////
//			System.out.println(curminGen.fitness+"curminGen.fitness-----");////////////////
			if(curminGen.fitness==null) continue;
			else if(curminGen.fitness<minGene.fitness) minGene.copy(curminGen);
			results[rindex++]=curminGen.fitness;
			if(rindex>9) rindex=0;
			//终止条件
			if(end()) {
				System.out.println(iter+"代---------"+(System.currentTimeMillis()-curt1));///////////////
				break;
			}
			//群体选择，产生下一代
			comSelect();
			nextGroup();
			iter++;
		}
		//结果返回
		this.minRoutes=new ArrayList<>();
		group[0]=minGene;
		comFintness(0, this.minRoutes);
		System.out.println("最小花费："+minGene.fitness);////////////
	}

}
