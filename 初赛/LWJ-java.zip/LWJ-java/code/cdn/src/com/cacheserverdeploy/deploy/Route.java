package com.cacheserverdeploy.deploy;

import java.util.List;

public class Route {
	public List<Integer> nodes;//存点的编号
	public int bandwith;

	public Route(List<Integer> nodes, int bandwith) {
		this.nodes = nodes;
		this.bandwith=bandwith;
	}	
}
