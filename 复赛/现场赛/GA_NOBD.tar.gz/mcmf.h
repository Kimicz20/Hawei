#ifndef _MCMF_H_
#define _MCMF_H_

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <utility>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <string>
#include <sstream>
#include <set>
#include <vector>
#include <stack>
#include <map>
#include <queue>
#include <deque>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <ctime>
#include <sys/types.h>
#include <unistd.h>
#include <functional>
#include <fstream>
#include <cassert>
#include "Graph.hpp"
using namespace std;

typedef long long int excessType,priceType;

class MCMF_YCW
{
        public:
                class ARC;
                //节点
                class NODE {
                        public:
                                excessType excessNodeVar;
                                priceType priceNodeVar;
                                ARC *firstNodeVar,*currentNodeVar,*suspendedNodeVar;
                                NODE *qNextNodeVar,*bNextNodeVar,*bPrevNodeVar;
                                long rankNodeVar, inpNodeVar;

                        public:
                                void set_excess( excessType excess) { excessNodeVar = excess; }
                                void dec_excess( long delta) { excessNodeVar -= delta; }
                                void inc_excess( long delta) { excessNodeVar += delta; }
                                void set_price( priceType price) { priceNodeVar = price; }
                                void dec_price( long delta) { priceNodeVar -= delta; }
                                void set_first( ARC *first) { firstNodeVar = first; }
                                void set_current( ARC *current) { currentNodeVar = current; }
                                void inc_current() { currentNodeVar ++; }
                                void set_suspended( ARC *suspended) { suspendedNodeVar = suspended; }
                                void set_q_next( NODE *q_next) { qNextNodeVar = q_next; }
                                void set_b_next( NODE *b_next) { bNextNodeVar = b_next; }
                                void set_b_prev( NODE *b_prev) { bPrevNodeVar = b_prev; }
                                void set_rank( long rank) { rankNodeVar = rank; }
                                void set_inp( long inp) { inpNodeVar = inp; }
                                excessType excess() { return excessNodeVar; }
                                priceType price() { return priceNodeVar; }
                                ARC *first() { return firstNodeVar; }
                                void dec_first() { firstNodeVar --; }
                                void inc_first() { firstNodeVar ++; }
                                ARC *current() { return currentNodeVar; }
                                ARC *suspended() { return suspendedNodeVar; }
                                NODE *q_next() { return qNextNodeVar; }
                                NODE *b_next() { return bNextNodeVar; }
                                NODE *b_prev() { return bPrevNodeVar; }
                                long rank() { return rankNodeVar; }
                                long inp() { return inpNodeVar; }
                };

                //弧定义
                class ARC {
                        public:
                                long rezCapacityARCVar; // 剩余容量
                                priceType costARCVar;       // 费用
                                NODE *headARCVar;
                                ARC *sisterARCVar;      // 相对弧
                        public:
                                void set_rez_capacity( long rez_capacity) { rezCapacityARCVar = rez_capacity; }
                                void dec_rez_capacity( long delta) { rezCapacityARCVar -= delta; }
                                void inc_rez_capacity( long delta) { rezCapacityARCVar += delta; }
                                void set_cost( priceType cost) { costARCVar = cost; }
                                void multiply_cost( priceType mult) { costARCVar *= mult; }
                                void set_head( NODE *head) { headARCVar = head; }
                                void set_sister( ARC *sister) { sisterARCVar = sister; }
                                long rez_capacity() { return rezCapacityARCVar; }
                                priceType cost() { return costARCVar; }
                                NODE *head() { return headARCVar; }
                                ARC *sister() { return sisterARCVar; }
                };



                //
                class BUCKET {
                        private:
                                NODE *pFirstBucketVar;
                        public:
                                BUCKET( NODE *p_first) : pFirstBucketVar(p_first) {}
                                BUCKET() {}
                                void set_p_first( NODE *p_first) { pFirstBucketVar = p_first; }
                                NODE *p_first() { return pFirstBucketVar; }
                };

                Graph G;
                //计算总费用需要的属性
                int netStates,consumeStates,totalNeed;
                map<int,pair<int,int> > serverLevel;//保存服务器档次信息
                map<int, int> serverAllPrice;//所有服务器用的架构费用
                map<int, int> getServerAllPrice();
                void setRealServerById(map<int, int>);// 根据虚拟点找到服务器的真实id
                map<int, int> realServerById;
                vector<int> netStateDeployPrice;//网络节点部署成本
                bool isOutputResult = false;
                set<int> itServers;
                long nodeNumYCWVar,arcNumYCWVar,*capArrayYCWVar;   // 容量数组
                NODE *nodesArrayYCWVar,*sentinelNode,*excqFirst,*excqLast;
                ARC *arcsArrayYCWVar,*sentinelArc;

                BUCKET *bucketsArrayYCWVar,*lBucket;
                long _linf;
                int timeForPriceIn;

                priceType epsilonYCWVar,_dn,priceMinYCWVar,_mmc;
                double fScaleYCWVar,cutOffFactor,cutOn,cutOff;
                excessType totalExcess;

                int flagPrice,flagUpdt,sncMaxYCWVar;

                ARC dArcYCWVar;
                NODE dOneNode,*_dummy_node,*dTwoNode;

                long nRelYCWVar,nRefYCWVar,nSrcYCWVar,nPushYCWVar,nRelabelYCWVar,nDischargeYCWVar,nRefineYCWVar,nUpdateYCWVar,nScanYCWVar,nPrscanYCWVar,nPrscanOneYCWVar;
                long nPrscanTwoYCWVar,nBadPricein,nBadRelabelYCWVar,nPrefineYCWVar;

                bool noZeroCycles,checkSolution,compDualsYCWVar,costRestartYCWVar,printAnsYCWVar;
                long long int *nodeBalanceYCWVar;

                long nodeMinYCWVar,nodeMaxYCWVar,*arcFirstYCWVar,*arcTailYCWVar,posCurrent;
                ARC *arcCurrent,*arcNew,*arcTmp;
                priceType maxCost;
                excessType totalPYCWVar,totalNYCWVar;

                NODE *iNode,*jNode;

                std::vector<int> serverMaxOutPutLimit;
                //需要计算总费用的构造函数
                MCMF_YCW(Graph &G,set<int> &itServers,vector<int> serverMaxOutPutLimit = vector<int>(2000,150))
                    :flagPrice(0),flagUpdt(0),nPushYCWVar(0),nRelabelYCWVar(0),nDischargeYCWVar(0),nRefineYCWVar(0),nUpdateYCWVar(0),nScanYCWVar(0),nPrscanYCWVar(0),
                nPrscanOneYCWVar(0),nPrscanTwoYCWVar(0),nBadPricein(0),nBadRelabelYCWVar(0),nPrefineYCWVar(0),noZeroCycles(false),checkSolution(false),compDualsYCWVar(false),
                costRestartYCWVar(false),printAnsYCWVar(true){

                        this->G = G;
                        this->itServers = itServers;
                        this->nodeNumYCWVar = G.netNodesNum+G.consumeNodesNum+1;
                        this->arcNumYCWVar = 2*G.arcNum+G.consumeNodesNum+itServers.size();
                        this->netStates = G.netNodesNum;
                        this->consumeStates = G.consumeNodesNum;
                        this->totalNeed = G.totalFlow;
                        this->serverMaxOutPutLimit =serverMaxOutPutLimit;
                        //服务器档次和网络节点部署费用
                        this->serverLevel = G.serverLevel;
                        this->netStateDeployPrice = G.netStateDeployPrice;

                        allocate_arrays();
                        convert2MCMF();
                }
                
                ~MCMF_YCW() {}

                void allocate_arrays();
                void deallocate_arrays();
                void set_arc( long tail_node_id, long head_node_id,
                                          long low_bound, long up_bound, priceType cost);
                void set_supply_demand_of_node( long id, long excess);
                void pre_processing() {
                    // called after the arcs were just added and before run_cs2();
                    // ordering arcs - linear time algorithm;
                    long i;
                    long last, arc_num, arc_new_num;;
                    long tail_node_id;
                    NODE *head_p;
                    ARC *arc_new, *arc_tmp;
                    long up_bound;
                    priceType cost; // arc cost;
                    excessType cap_out; // sum of outgoing capacities
                    excessType cap_in; // sum of incoming capacities

                    // first arc from the first node
                    ( nodesArrayYCWVar + nodeMinYCWVar )->set_first( arcsArrayYCWVar );

                    for ( i = nodeMinYCWVar + 1; i <= nodeMaxYCWVar + 1; i ++ ) {
                            arcFirstYCWVar[i] += arcFirstYCWVar[i-1];
                            ( nodesArrayYCWVar + i )->set_first( arcsArrayYCWVar + arcFirstYCWVar[i] );
                    }

                    // scanning all the nodes except the last
                    for ( i = nodeMinYCWVar; i < nodeMaxYCWVar; i ++ ) {

                            last = ( ( nodesArrayYCWVar + i + 1 )->first() ) - arcsArrayYCWVar;

                            for ( arc_num = arcFirstYCWVar[i]; arc_num < last; arc_num ++ ) {
                                    tail_node_id = arcTailYCWVar[arc_num];

                                    while ( tail_node_id != i ) {

                                            arc_new_num = arcFirstYCWVar[tail_node_id];
                                            arcCurrent = arcsArrayYCWVar + arc_num;
                                            arc_new = arcsArrayYCWVar + arc_new_num;

                                            head_p = arc_new->head();
                                            arc_new->set_head( arcCurrent->head() );
                                            arcCurrent->set_head( head_p );

                                            up_bound          = capArrayYCWVar[arc_new_num];
                                            capArrayYCWVar[arc_new_num] = capArrayYCWVar[arc_num];
                                            capArrayYCWVar[arc_num]     = up_bound;

                                            up_bound = arc_new->rez_capacity();
                                            arc_new->set_rez_capacity( arcCurrent->rez_capacity() );
                                            arcCurrent->set_rez_capacity( up_bound) ;

                                            cost = arc_new->cost();
                                            arc_new->set_cost( arcCurrent->cost() );
                                            arcCurrent->set_cost( cost );

                                            if ( arc_new != arcCurrent->sister() ) {
                                                    arc_tmp = arc_new->sister();
                                                    arc_new->set_sister( arcCurrent->sister() );
                                                    arcCurrent->set_sister( arc_tmp );

                                                    arcCurrent->sister()->set_sister( arcCurrent );
                                                    arc_new->sister()->set_sister( arc_new );
                                            }

                                            arcTailYCWVar[arc_num] = arcTailYCWVar[arc_new_num];
                                            arcTailYCWVar[arc_new_num] = tail_node_id;

                                            // we increase arc_first[tail_node_id]
                                            arcFirstYCWVar[tail_node_id] ++ ;

                                            tail_node_id = arcTailYCWVar[arc_num];
                                    }
                            }
                            // all arcs outgoing from  i  are in place
                    }

                    for ( NODE *ndp = nodesArrayYCWVar + nodeMinYCWVar; ndp <= nodesArrayYCWVar + nodeMaxYCWVar; ndp ++ ) {
                            cap_in  =   ( ndp->excess() );
                            cap_out = - ( ndp->excess() );
                            for ( arcCurrent = ndp->first(); arcCurrent != (ndp+1)->first();
                                    arcCurrent ++ ) {
                                    arc_num = arcCurrent - arcsArrayYCWVar;
                                    if ( capArrayYCWVar[arc_num] > 0 ) cap_out += capArrayYCWVar[arc_num];
                                    if ( capArrayYCWVar[arc_num] == 0 )
                                            cap_in += capArrayYCWVar[ arcCurrent->sister() - arcsArrayYCWVar ];
                            }
                    }

                    // adjustments due to nodes' ids being between _node_min - _node_max;
                    nodeNumYCWVar = nodeMaxYCWVar - nodeMinYCWVar + 1;
                    nodesArrayYCWVar = nodesArrayYCWVar + nodeMinYCWVar;

                    // () free internal memory, not needed anymore inside CS2;
                    free ( arcFirstYCWVar );
                    free ( arcTailYCWVar );
            }
                void cs2_initialize();
                void up_node_scan( NODE *i) {
                        NODE *j; // opposite node
                        ARC *a; // (i, j)
                        ARC *a_stop; // first arc from the next node
                        ARC *ra; // (j, i)
                        BUCKET *b_old; // old bucket contained j
                        BUCKET *b_new; // new bucket for j
                        long i_rank;
                        long j_rank; // ranks of nodes
                        long j_new_rank;
                        priceType rc; // reduced cost of (j, i)
                        priceType dr; // rank difference

                        nScanYCWVar ++;

                        i_rank = i->rank();

                        // scanning arcs;
                        for ( a = i->first(), a_stop = (i + 1)->suspended(); a != a_stop; a ++ ) {

                                ra = a->sister();

                                if ( ra->rez_capacity() > 0 ) {
                                        j = a->head();
                                        j_rank = j->rank();

                                        if ( j_rank > i_rank ) {
                                                if ( ( rc = j->price() + ra->cost() - i->price() ) < 0 ) {
                                                        j_new_rank = i_rank;
                                                } else {
                                                        dr = rc / epsilonYCWVar;
                                                        j_new_rank = ( dr < _linf ) ? i_rank + (long)dr + 1 : _linf;
                                                }

                                                if ( j_rank > j_new_rank ) {
                                                        j->set_rank( j_new_rank);
                                                        j->set_current( ra);

                                                        if ( j_rank < _linf ) {
                                                                b_old = bucketsArrayYCWVar + j_rank;
                                                                // REMOVE_FROM_BUCKET( j, b_old );
                                                                if ( j == ( b_old -> p_first() ) )
                                                                        b_old ->set_p_first( j -> b_next() );
                                                                else
                                                                {
                                                                        ( j -> b_prev() )->set_b_next( j -> b_next() );
                                                                        ( j -> b_next() )->set_b_prev( j -> b_prev() );
                                                                }
                                                        }

                                                        b_new = bucketsArrayYCWVar + j_new_rank;
                                                        insert_to_bucket( j, b_new );
                                                }
                                        }
                                }
                        }

                        i->dec_price( i_rank * epsilonYCWVar);
                        i->set_rank( -1);
                }
                void price_update();
                int relabel( NODE *i);
                void discharge( NODE *i);
                int price_in() {
                        NODE *i; // current node
                        NODE *j;
                        ARC *a; // current arc from i
                        ARC *a_stop; // first arc from the next node
                        ARC *b; // arc to be exchanged with suspended
                        ARC *ra; // opposite to a
                        ARC *rb; // opposite to b
                        priceType rc; // reduced cost
                        int n_in_bad; // number of priced_in arcs with negative reduced cost
                        int bad_found; // if 1 we are at the second scan if 0 we are at the first scan
                        excessType i_exc; // excess of i
                        excessType df; // an amount to increase flow


                        bad_found = 0;
                        n_in_bad = 0;

                restart:

                        for ( i = nodesArrayYCWVar; i != sentinelNode; i ++ ) {

                                for ( a = i->first() - 1, a_stop = i->suspended() - 1; a != a_stop; a -- ) {

                                        rc = i->price() + a->cost() - a->head()->price();
                                        if ( ( rc < 0) && ( a->rez_capacity() > 0) ) { // bad case;
                                                if ( bad_found == 0 ) {
                                                        bad_found = 1;
                                                        update_cut_off();
                                                        goto restart;
                                                }
                                                df = a->rez_capacity();
                                                increase_flow( i, a->head(), a, df );

                                                ra = a->sister();
                                                j  = a->head();

                                                i->dec_first();
                                                b = i->first();
                                                exchange( a, b );

                                                if ( a < j->first() ) {
                                                        j->dec_first();
                                                        rb = j->first();
                                                        exchange( ra, rb );
                                                }

                                                n_in_bad ++;
                                        } else {
                                                if ( ( rc < cutOn ) && ( rc > -cutOn ) ) {
                                                        i->dec_first();
                                                        b = i->first();
                                                        exchange( a, b );
                                                }
                                        }
                                }
                        }


                        if ( n_in_bad != 0 ) {

                                nBadPricein ++;

                                // recalculating excess queue;
                                totalExcess = 0;
                                nSrcYCWVar = 0;
                                reset_excess_q();

                                for ( i = nodesArrayYCWVar; i != sentinelNode; i ++ ) {
                                        i->set_current( i->first());
                                        i_exc = i->excess();
                                        if ( i_exc > 0 ) { // i is a source;
                                                totalExcess += i_exc;
                                                nSrcYCWVar ++;
                                                insert_to_excess_q( i );
                                        }
                                }

                                insert_to_excess_q( _dummy_node );
                        }

                        if ( timeForPriceIn == 4)
                                timeForPriceIn = 6;
                        if ( timeForPriceIn == 2)
                                timeForPriceIn = 4;

                        return ( n_in_bad);
                }
                int refine();
                int price_refine() {
                        NODE *i; // current node
                        NODE *j; // opposite node
                        NODE *ir; // nodes for passing over the negative cycle
                        NODE *is;
                        ARC *a; // arc (i,j)
                        ARC *a_stop; // first arc from the next node
                        ARC *ar;
                        long bmax;            // number of farest nonempty bucket
                        long i_rank;          // rank of node i
                        long j_rank;         // rank of node j
                        long j_new_rank;      // new rank of node j
                        BUCKET *b;              // current bucket
                        BUCKET *b_old;          // old and new buckets of current node
                        BUCKET *b_new;
                        priceType rc = 0; // reduced cost of a
                        priceType dr; // ranks difference
                        priceType dp;
                        int cc;
                        // return code: 1 - flow is epsilon optimal
                        // 0 - refine is needed
                        long df; // cycle capacity
                        int nnc; // number of negative cycles cancelled during one iteration
                        int snc; // total number of negative cycle cancelled

                        nPrefineYCWVar ++;

                        cc = 1;
                        snc = 0;

                        sncMaxYCWVar = 0;


                        // (1) main loop
                        // while negative cycle is found or eps-optimal solution is constructed
                        while ( 1 ) {

                                nnc = 0;
                                for ( i = nodesArrayYCWVar; i != sentinelNode; i ++ ) {
                                        i->set_rank( 0);
                                        i->set_inp( 0);
                                        i->set_current( i->first());
                                }
                                reset_stackq();

                                for ( i = nodesArrayYCWVar; i != sentinelNode; i ++ ) {
                                        if ( i->inp() == 2 ) continue;

                                        i->set_b_next( NULL);

                                        // deapth first search
                                        while ( 1 ) {
                                                i->set_inp(1);

                                                // scanning arcs from node i starting from current
                                                for ( a = i->current(), a_stop = (i + 1)->suspended(); a != a_stop; a ++) {
                                                        if ( (a->rez_capacity() > 0) ) {
                                                                j = a->head();
                                                                if ( i->price() + a->cost() - j->price() < 0 ) {
                                                                        if ( j->inp() == 0 ) { // fresh node  - step forward
                                                                                i->set_current( a);
                                                                                j->set_b_next( i);
                                                                                i = j;
                                                                                a = j->current();
                                                                                a_stop = (j+1)->suspended();
                                                                                break;
                                                                        }

                                                                        if ( j->inp() == 1 ) { // cycle detected
                                                                                cc = 0;
                                                                                nnc ++;
                                                                                i->set_current( a);
                                                                                is = ir = i;
                                                                                df = 0x7fffffff;

                                                                                while ( 1 ) {
                                                                                        ar = ir->current();
                                                                                        if ( ar->rez_capacity() <= df ) {
                                                                                                df = ar->rez_capacity();
                                                                                                is = ir;
                                                                                        }
                                                                                        if ( ir == j ) break;
                                                                                        ir = ir->b_next();
                                                                                }

                                                                                ir = i;

                                                                                while ( 1 ) {
                                                                                        ar = ir->current();
                                                                                        increase_flow( ir, ar->head(), ar, df);
                                                                                        if ( ir == j ) break;
                                                                                        ir = ir->b_next();
                                                                                }

                                                                                if ( is != i ) {
                                                                                        for ( ir = i; ir != is; ir = ir->b_next() ) {
                                                                                                ir->set_inp( 0);
                                                                                        }
                                                                                        i = is;
                                                                                        a = is->current() + 1;
                                                                                        a_stop = (is+1)->suspended();
                                                                                        break;
                                                                                }
                                                                        }
                                                                }
                                                                // if j-color is BLACK - continue search from i
                                                        }
                                                } // all arcs from i are scanned

                                                if ( a == a_stop ) {
                                                        // step back
                                                        i->set_inp( 2);
                                                        nPrscanOneYCWVar ++;
                                                        j = i->b_next();
                                                        stackq_push( i );
                                                        if ( j == NULL ) break;
                                                        i = j;
                                                        i->inc_current();
                                                }

                                        } // end of deapth first search
                                } // all nodes are scanned


                                // () no negative cycle
                                // computing longest paths with eps-precision

                                snc += nnc;
                                if ( snc < sncMaxYCWVar ) cc = 1;
                                if ( cc == 0 ) break;
                                bmax = 0;

                                while ( nonempty_stackq() ) {

                                        nPrscanTwoYCWVar ++;
                                        // STACKQ_POP( i );
                                        i = excqFirst;
                                        excqFirst = i -> q_next();
                                        i ->set_q_next( sentinelNode );
                                        i_rank = i->rank();
                                        for ( a = i->first(), a_stop = (i + 1)->suspended(); a != a_stop; a ++) {

                                                if (a->rez_capacity() > 0) {
                                                        j  = a->head();
                                                        rc = i->price() + a->cost() - j->price();

                                                        if ( rc < 0 ) { // admissible arc;
                                                                dr = (priceType) (( - rc - 0.5 ) / epsilonYCWVar);
                                                                if (( j_rank = dr + i_rank ) < _linf ) {
                                                                        if ( j_rank > j->rank() )
                                                                                j->set_rank( j_rank);
                                                                }
                                                        }
                                                }
                                        } // all arcs from i are scanned

                                        if ( i_rank > 0 ) {
                                                if ( i_rank > bmax ) bmax = i_rank;
                                                b = bucketsArrayYCWVar + i_rank;
                                                insert_to_bucket( i, b );
                                        }
                                } // end of while-cycle: all nodes are scanned - longest distancess are computed;


                                if ( bmax == 0 ) { // preflow is eps-optimal;
                                        break;
                                }


                                for ( b = bucketsArrayYCWVar + bmax; b != bucketsArrayYCWVar; b -- ) {
                                        i_rank = b - bucketsArrayYCWVar;
                                        dp = i_rank * epsilonYCWVar;

                                        while ( nonempty_bucket( b) ) {
                                                // GET_FROM_BUCKET( i, b );
                                                i=(b -> p_first() );
                                                b ->set_p_first( i -> b_next() );
                                                nPrscanYCWVar ++;

                                                for ( a = i->first(), a_stop = (i + 1)->suspended(); a != a_stop; a ++) {
                                                        if (a->rez_capacity() > 0) {
                                                                j = a->head();
                                                                j_rank = j->rank();
                                                                if ( j_rank < i_rank ) {
                                                                        rc = i->price() + a->cost() - j->price();
                                                                        if ( rc < 0 ) {
                                                                                j_new_rank = i_rank;
                                                                        } else {
                                                                                dr = rc / epsilonYCWVar;
                                                                                j_new_rank = ( dr < _linf ) ? i_rank - ( (long)dr + 1 ) : 0;
                                                                        }
                                                                        if ( j_rank < j_new_rank ) {
                                                                                if ( cc == 1 ) {
                                                                                        j->set_rank( j_new_rank);
                                                                                        if ( j_rank > 0 ) {
                                                                                                b_old = bucketsArrayYCWVar + j_rank;
                                                                                                // REMOVE_FROM_BUCKET( j, b_old );
                                                                                                if ( j == ( b_old -> p_first() ) )
                                                                                                        b_old ->set_p_first( j -> b_next() );
                                                                                                else
                                                                                                {
                                                                                                        ( j -> b_prev() )->set_b_next( j -> b_next() );
                                                                                                        ( j -> b_next() )->set_b_prev( j -> b_prev() );
                                                                                                }
                                                                                        }
                                                                                        b_new = bucketsArrayYCWVar + j_new_rank;
                                                                                        insert_to_bucket( j, b_new );
                                                                                } else {
                                                                                        df = a->rez_capacity();
                                                                                        increase_flow( i, j, a, df );
                                                                                }
                                                                        }
                                                                }
                                                        } // end if opened arc
                                                } // all arcs are scanned

                                                i->dec_price( dp);

                                        } // end of while-cycle: the bucket is scanned
                                } // end of for-cycle: all buckets are scanned

                                if ( cc == 0 ) break;

                        } // end of main loop



                        // (2) finish
                        // if refine needed - saturate non-epsilon-optimal arcs;

                        if ( cc == 0 ) {
                                for ( i = nodesArrayYCWVar; i != sentinelNode; i ++) {
                                        for ( a = i->first(), a_stop = (i + 1)->suspended(); a != a_stop; a ++) {
                                                if ( i->price() + a->cost() - a->head()->price() < - epsilonYCWVar ) {
                                                        if ( ( df = a->rez_capacity() ) > 0 ) {
                                                                increase_flow( i, a->head(), a, df );
                                                        }
                                                }
                                        }
                                }
                        }

                        return ( cc );
                }
                void compute_prices();
                void price_out();
                int update_epsilon();
                int check_feas();
                int check_cs();
                int check_eps_opt();
                void init_solution();
                void cs_cost_reinit() {
                        if ( costRestartYCWVar == false)
                                return;

                        NODE *i; // current node
                        ARC *a;          // current arc
                        ARC *a_stop;
                        BUCKET *b; // current bucket
                        priceType rc, minc, sum;


                        for ( b = bucketsArrayYCWVar; b != lBucket; b ++) {
                                reset_bucket( b);
                        }

                        rc = 0;
                        for ( i = nodesArrayYCWVar; i != sentinelNode; i ++) {
                                rc = rc < i->price()?rc:i->price();
                                i->set_first( i->suspended());
                                i->set_current( i->first());
                                i->set_q_next( sentinelNode);
                        }

                        // make prices nonnegative and multiply
                        for ( i = nodesArrayYCWVar; i != sentinelNode; i ++) {
                                i->set_price( (i->price() - rc) * _dn);
                        }

                        // multiply arc costs
                        for (a = arcsArrayYCWVar; a != sentinelArc; a ++) {
                                a->multiply_cost( _dn);
                        }

                        sum = 0;
                        for ( i = nodesArrayYCWVar; i != sentinelNode; i ++) {
                                minc = 0;
                                for ( a = i->first(), a_stop = (i + 1)->suspended(); a != a_stop; a ++) {
                                        if ( ((a->rez_capacity() > 0) && ((rc = i->price() + a->cost() - a->head()->price()) < 0)) )
                                                minc =  epsilonYCWVar > -rc?epsilonYCWVar:-rc;
                                }
                                sum += minc;
                        }

                        epsilonYCWVar = ceil(sum / _dn);

                        cutOffFactor = 1.5 * pow((double)nodeNumYCWVar, 0.44);

                        cutOffFactor =  cutOffFactor > 12 ? cutOffFactor:12;

                        nRefYCWVar = 0;

                        nRefineYCWVar = nDischargeYCWVar = nPushYCWVar = nRelabelYCWVar = 0;
                        nUpdateYCWVar = nScanYCWVar = nPrefineYCWVar = nPrscanYCWVar = nPrscanOneYCWVar =
                                                               nBadPricein = nBadRelabelYCWVar = 0;

                        flagPrice = 0;

                        excqFirst = NULL;
                }
                void cs2_cost_restart( double *objective_cost);
                void print_solution(string& result);
                void print_graph();
                void finishup( double *objective_cost);
                void cs2( double *objective_cost);
                int greenTea() {
                        double objective_cost;


                        // (4) ordering, etc.;

                        pre_processing();

                        // () CHECK_SOLUTION?
                        if ( checkSolution == true) {
                                nodeBalanceYCWVar = (long long int *) calloc (nodeNumYCWVar+1, sizeof(long long int));
                                for ( NODE *i = nodesArrayYCWVar; i < nodesArrayYCWVar + nodeNumYCWVar; i ++ ) {
                                        nodeBalanceYCWVar[i - nodesArrayYCWVar] = i->excess();
                                }
                        }


                        // (5) initializations;
                        arcNumYCWVar = 2 * arcNumYCWVar;
                        cs2_initialize(); // works already with 2*m;

                        // (6) run CS2;
                        cs2( &objective_cost );


                        if(objective_cost<0){
                                if(!isOutputResult){
                                        deallocate_arrays();
                                }


                                return -1;
                        }else{
                                // cout<<"加总费用之前："<<objective_cost<<endl;
                                addServerAndDeployPrice(&objective_cost);

                                if(!isOutputResult){
                                        // () cleanup;
                                        deallocate_arrays();
                                }
                                return objective_cost;
                        }


                }
                int addServerAndDeployPrice(double *cost);
                void storeServerGrade();
                pair<int,int> determineDC(int serverOutput);
                //确定存储每个服务器的档次
                void server_dc_mapstoreServerGrade();
                void convert2MCMF();
                void increase_flow( NODE *i, NODE *j, ARC *a, long df) {
                        i->dec_excess( df);
                        j->inc_excess( df);
                        a->dec_rez_capacity( df);
                        a->sister()->inc_rez_capacity( df);
                }
                bool time_for_update() {
                        return ( nRelYCWVar > nodeNumYCWVar * 0.4 + nSrcYCWVar * 30);
                }
                void reset_excess_q() {
                        for ( ; excqFirst != NULL; excqFirst = excqLast ) {
                                excqLast = excqFirst->q_next();
                                excqFirst->set_q_next( sentinelNode);
                        }
                }
                bool out_of_excess_q( NODE *i) { return ( i->q_next() == sentinelNode); }
                bool empty_excess_q() { return ( excqFirst == NULL); }
                bool nonempty_excess_q() { return ( excqFirst != NULL); }
                void insert_to_excess_q( NODE *i) {
                        if ( nonempty_excess_q() ) {
                                excqLast->set_q_next( i);
                        } else {
                                excqFirst = i;
                        }
                        i->set_q_next( NULL);
                        excqLast = i;
                }
                void insert_to_front_excess_q( NODE *i) {
                        if ( empty_excess_q() ) {
                                excqLast = i;
                        }
                        i->set_q_next( excqFirst);
                        excqFirst = i;
                }
                void remove_from_excess_q( NODE *i) {
                        i = excqFirst;
                        excqFirst = i->q_next();
                        i->set_q_next( sentinelNode);
                }
                bool empty_stackq() { return empty_excess_q(); }
                bool nonempty_stackq() { return nonempty_excess_q(); }
                void reset_stackq() { reset_excess_q(); }
                void stackq_push( NODE *i) {
                        i->set_q_next( excqFirst);
                        excqFirst = i;
                }
                void stackq_pop( NODE *i) {
                        remove_from_excess_q( i);
                }
                void reset_bucket( BUCKET *b) { b->set_p_first( dTwoNode); }
                bool nonempty_bucket( BUCKET *b) { return ( (b->p_first()) != dTwoNode); }
                void insert_to_bucket( NODE *i, BUCKET *b) {
                        i->set_b_next( b->p_first() );
                        b->p_first()->set_b_prev( i);
                        b->set_p_first( i);
                }
                void get_from_bucket( NODE *i, BUCKET *b) {
                        i = b->p_first();
                        b->set_p_first( i->b_next());
                }
                void remove_from_bucket( NODE *i, BUCKET *b) {
                        if ( i == b->p_first() ) {
                                b->set_p_first( i->b_next());
                        } else {
                                i->b_prev()->set_b_next( i->b_next());
                                i->b_next()->set_b_prev( i->b_prev());
                        }
                }
                void update_cut_off() {
                        if ( nBadPricein + nBadRelabelYCWVar == 0) {
                                cutOffFactor = pow( (double)nodeNumYCWVar, 0.75 );
                                cutOffFactor = cutOffFactor > 12 ? cutOffFactor:12;
                                cutOff = cutOffFactor * epsilonYCWVar;
                                cutOn = cutOff * 0.8;
                        } else {
                                cutOffFactor *= 4;
                                cutOff = cutOffFactor * epsilonYCWVar;
                                cutOn = cutOff * 0.8;
                        }
                }
                void exchange( ARC *a, ARC *b) {
                        if ( a != b) {
                                ARC *sa = a->sister();
                                ARC *sb = b->sister();
                                long d_cap;

                                dArcYCWVar.set_rez_capacity( a->rez_capacity());
                                dArcYCWVar.set_cost( a->cost());
                                dArcYCWVar.set_head( a->head());

                                a->set_rez_capacity( b->rez_capacity());
                                a->set_cost( b->cost());
                                a->set_head( b->head());

                                b->set_rez_capacity( dArcYCWVar.rez_capacity());
                                b->set_cost( dArcYCWVar.cost());
                                b->set_head( dArcYCWVar.head());

                                if ( a != sb) {
                                        b->set_sister( sa);
                                        a->set_sister( sb);
                                        sa->set_sister( b);
                                        sb->set_sister( a);
                                }

                                d_cap = capArrayYCWVar[ a - arcsArrayYCWVar];
                                capArrayYCWVar[ a - arcsArrayYCWVar] = capArrayYCWVar[ b - arcsArrayYCWVar];
                                capArrayYCWVar[ b - arcsArrayYCWVar] = d_cap;
                        }
                }
};
#endif